<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
class Cronjob extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mymodel');
	} 
	public function event_reminder()
	{
		$get_event_reminder = $this->db->query("select event_id, user_id, event_name, event_date, event_time, event_address from event WHERE (event_date BETWEEN DATE_ADD(DATE(NOW()), INTERVAL 2 DAY) AND DATE_ADD(DATE(NOW()), INTERVAL 2 DAY)) OR (event_date BETWEEN DATE_ADD(DATE(NOW()), INTERVAL 1 DAY) AND DATE_ADD(DATE(NOW()), INTERVAL 1 DAY))");
		$result = ($get_event_reminder->num_rows() > 0) ? $get_event_reminder->result() : '';
		$from_email = "info@madetosplit.com"; 
		$imagebackPath = '';
		//print_r($result);die;
		
		foreach($result as $k => $v){
			$subject = "Event Reminder (".@$v->event_name.")";
			$imagePath = base_url() . 'uploads/logos/logo.png';
			$imagebackPath = '';
			$mesg = "<!Doctype html>
			<html>
				<head>
					<meta charset='utf-8'>
					<meta name='viewport' content='width=device-width, initial-scale=1'>
					<title>Invite People</title>
					<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
					</head>
				<body>
					<div style='max-width:600px;
					margin:auto;
					border:1px solid #eee;
					box-shadow:0 0 10px rgba(0, 0, 0, .15);
					line-height:17px;
					font-size:13px;
					box-sizing:border-box; -webkit-print-color-adjust: exact;font-family: Poppins, sans-serif; background:url(".$imagebackPath.")'>
						<div style='padding:20px; box-sizing: border-box;text-align: center; background: #fff;'>
							<a href='#'><img src='".$imagePath."' style='width: 350px; height80px;'></a>
						</div>
						<div style='width: 400px; margin:50px auto;background: #ffffffd1;padding: 50px;text-align: center;'>
							<h1 style=' font-size: 30px; line-height: 32px; color: #0b0b0b; margin: 30px 0;'>Dear User</h1>
							<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;text-align: justify;'>We hope this email finds you well. This is a friendly reminder that our event is just a few days away! We want to ensure you have all the details to make your experience as smooth as possible.</p>
						</div>
						
						<div style='margin: 0px 96px;margin-top: -60px;'>
							<span><strong>Event &nbsp; : &nbsp; </strong>  ".@$v->event_name."</span>	<br>
							<span><strong>Venue &nbsp; : &nbsp; </strong>".@$v->event_address."</span>	<br>
							<span><strong>Date & Time &nbsp; : &nbsp; </strong>".date('d M, Y', strtotime(@$v->event_date)) .' '.@$v->event_time."</span>
						</div><br>
						<div style='background: #f7931e;width: 20%;margin: 5px 13rem;border-radius: 7px;'>
						<a href='".base_url('event/details?eId='.base64_encode(@$v->event_id).'')."' style='padding: 9px 0px;position: absolute;margin: 0px 22px;text-decoration: none;font-size: 14px;font-weight: 900;color: white;'>Check Here</a><br><br>
						</div>
						<div style='background: #000;
						text-align: left;
						box-sizing: border-box;
						width: 100%;
						padding: 20px 50px;
						color: #fff;'>
							<p style='margin: 5px 0;font-size: 12px;'>Warm Regards,</p>
							<p style='margin: 5px 0;font-size: 12px;'>Made to Split</p>
							<p style='margin: 5px 0;font-size: 12px;'><strong>Email:</strong> <a href='#' style='color: #78daff;'>info@madetosplit.com</a></p>
							<br/>
							<p style='margin: 5px 0;font-size: 11px;'>This is an automated response, please do not reply.</p>
						</div>
					</div>
				</body>
			</html>";
		
			$get_invited_people = $this->db->query("select * from event_invited_people where event_id = ".@$v->event_id."")->result();
			foreach($get_invited_people as $key => $value){
				$user_info = $this->Mymodel->get_single_row_info('id, email, fname, lname', 'users', 'email="'.$value->email.'"', '', 1);
				if(!empty($user_info)){
					$this->Mymodel->send_mail($user_info->email, $from_email, $mesg, $subject, 'rameshwebdev21@gmail.com', 'gqbtiijrzaljwkhz');
				}
			}
		}
	}
	function subscription_reminder(){
		$get_event_reminder = $this->db->query("select id, user_id, sub_id, start_date, end_date, status from transaction WHERE ((DATE(end_date) BETWEEN DATE_ADD(DATE(NOW()), INTERVAL 2 DAY) AND DATE_ADD(DATE(NOW()), INTERVAL 2 DAY)) OR (DATE(end_date) BETWEEN DATE_ADD(DATE(NOW()), INTERVAL 1 DAY) AND DATE_ADD(DATE(NOW()), INTERVAL 1 DAY))) AND payment_type = '1' AND subscription IS NULL AND status = 'succeeded'");
		$result = ($get_event_reminder->num_rows() > 0) ? $get_event_reminder->result() : '';
		foreach($result as $k => $v){
			$subject = "Subscription Reminder";
			$from_email = "info@madetosplit.com"; 
			$imagePath = base_url() . 'uploads/logos/logo.png';
			$imagebackPath = '';
			$user_info = $this->Mymodel->get_single_row_info('id, email, fname, lname', 'users', 'id="'.$v->user_id.'"', '', 1);
			$sub_info = $this->Mymodel->get_single_row_info('id, name', 'subscription', 'id="'.$v->sub_id.'"', '', 1);
			
			
				$mesg = "<!Doctype html>
				<html>
				<head>
					<meta charset='utf-8'>
					<meta name='viewport' content='width=device-width, initial-scale=1'>
					<title>Invite People</title>
					<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
					</head>
				<body>
					<div style='max-width:600px;
					margin:auto;
					border:1px solid #eee;
					box-shadow:0 0 10px rgba(0, 0, 0, .15);
					line-height:17px;
					font-size:13px;
					box-sizing:border-box; -webkit-print-color-adjust: exact;font-family: Poppins, sans-serif; background:url(".$imagebackPath.")'>
						<div style='padding:20px; box-sizing: border-box;text-align: center; background: #fff;'>
							<a href='#'><img src='".$imagePath."' style='width: 350px; height80px;'></a>
						</div>
						
						<div style='width: 400px; margin:50px auto;background: #ffffffd1;padding: 50px;text-align: center;'>
							<h1 style=' font-size: 30px; line-height: 32px; color: #0b0b0b; margin: 30px 0;'>Dear User</h1>
							<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;text-align: justify;'>We are reaching out to remind you that your subscription is expire on  <strong>".date('d M, Y', strtotime($v->end_date)).".</strong></p>
							
							<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;text-align: justify;'>Please renew your subscription plan.</p>
						</div>
						
						
						
						<div style='margin: 0px 96px;margin-top: -60px;'>
							<span><strong>Plan &nbsp; : &nbsp; </strong> ".@$sub_info->name."</span><br>
							<span><strong>Expired on &nbsp; : &nbsp; </strong>".date('d M, Y', strtotime($v->end_date))."</span><br>
						</div><br>
						
						<div style='background: #f7931e;width: 20%;margin: 5px 13rem;border-radius: 7px;'>
						<a href='".base_url('subscription')."' style='padding: 9px 0px;position: absolute;margin: 0px 22px;text-decoration: none;font-size: 14px;font-weight: 900;color: white;'>Renew Now</a><br><br>
						</div>
						
						<div style='background: #000;
						text-align: left;
						box-sizing: border-box;
						width: 100%;
						padding: 20px 50px;
						color: #fff;'>
							<p style='margin: 5px 0;font-size: 12px;'>Warm Regards,</p>
							<p style='margin: 5px 0;font-size: 12px;'>Made to Split</p>
							<p style='margin: 5px 0;font-size: 12px;'><strong>Email:</strong> <a href='#' style='color: #78daff;'>info@madetosplit.com</a></p>
							<br/>
							<p style='margin: 5px 0;font-size: 11px;'>This is an automated response, please do not reply.</p>
						</div>
					</div>
				</body>
			</html>";
			$this->Mymodel->send_mail($user_info->email, $from_email, $mesg, $subject, 'rameshwebdev21@gmail.com', 'gqbtiijrzaljwkhz');
		}
	}
	function test(){
		$imagePath = base_url() . 'uploads/logos/logo.png';
		$imagebackPath = '';
		$mesg = "<!Doctype html>
		<html>
			<head>
				<meta charset='utf-8'>
				<meta name='viewport' content='width=device-width, initial-scale=1'>
				<title>Invite People</title>
				<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
				</head>
			<body>
				<div style='max-width:600px;
				margin:auto;
				border:1px solid #eee;
				box-shadow:0 0 10px rgba(0, 0, 0, .15);
				line-height:17px;
				font-size:13px;
				box-sizing:border-box; -webkit-print-color-adjust: exact;font-family: Poppins, sans-serif; background:url(".$imagebackPath.")'>
					<div style='padding:20px; box-sizing: border-box;text-align: center; background: #fff;'>
						<a href='#'><img src='".$imagePath."' style='width: 350px; height80px;'></a>
					</div>
					
					<div style='width: 400px; margin:50px auto;background: #ffffffd1;padding: 50px;text-align: center;'>
						<h1 style=' font-size: 30px; line-height: 32px; color: #0b0b0b; margin: 30px 0;'>Dear User</h1>
						<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;text-align: justify;'>We are reaching out to remind you that your subscription is expire on  <strong>23 Jul 2023.</strong></p>
						
						<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;text-align: justify;'>Please renew your subscription plan.</p>
					</div>
					
					
					
					<div style='margin: 0px 96px;margin-top: -60px;'>
						<span><strong>Plan &nbsp; : &nbsp; </strong> Platinum</span><br>
						<span><strong>Expired on &nbsp; : &nbsp; </strong>23 Jul 2023</span><br>
					</div><br>
					
					<div style='background: #f7931e;width: 20%;margin: 5px 13rem;border-radius: 7px;'>
					<a href='' style='padding: 9px 0px;position: absolute;margin: 0px 22px;text-decoration: none;font-size: 14px;font-weight: 900;color: white;'>Renew Now</a><br><br>
					</div>
					
					<div style='background: #000;
					text-align: left;
					box-sizing: border-box;
					width: 100%;
					padding: 20px 50px;
					color: #fff;'>
						<p style='margin: 5px 0;font-size: 12px;'>Warm Regards,</p>
						<p style='margin: 5px 0;font-size: 12px;'>Made to Split</p>
						<p style='margin: 5px 0;font-size: 12px;'><strong>Email:</strong> <a href='#' style='color: #78daff;'>info@madetosplit.com</a></p>
						<br/>
						<p style='margin: 5px 0;font-size: 11px;'>This is an automated response, please do not reply.</p>
					</div>
				</div>
			</body>
		</html>";
		echo $mesg;
	}
}