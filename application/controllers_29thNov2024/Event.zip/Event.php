<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
class Event extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mymodel');
		$this->Mymodel->loggedIn();
		$this->session->keep_flashdata('msg');
	} 
	public function index()
	{
		
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Event List',
			'subpage' => 'event',
		);
		//$event_id = [];
		$userId = $this->session->userdata('loguserId');
		$user_email = $this->Mymodel->get_single_row_info('email', 'users', 'id='.$userId.'', '', 1);
		// //echo $this->db->last_query();
		// //print_r($user_email);die;
		// $getinvite_people = $this->db->query("select email, event_id from event_invited_people where email = '".$user_email->email."'")->result();
		
		// //print_r($getinvite_people);

		// if(!empty($getinvite_people)){
			// foreach($getinvite_people as $k => $v){
				// $event_id[] = $v->event_id;
			// }
			// $event_id = join(",",$event_id);
		// }
        
		
        $query = $this->db->query("select * from event where status = '1' and (user_id = ".$userId." OR event_id IN(select event_id from event_invited_people where email = '".$user_email->email."')) ORDER BY event_id DESC LIMIT 2");
		$data['event'] = ($query->num_rows() > 0) ? $query->result() : FALSE;
		
		$query = $this->db->query("select * from event where status = '1' and (user_id = ".$userId." OR event_id IN(select event_id from event_invited_people where email = '".$user_email->email."')) ORDER BY event_id DESC");
		$data['eventCount'] = ($query->num_rows() > 0) ? $query->num_rows() : FALSE;
		
		$this->load->view('header', $data);
		$this->load->view('account/event');
		$this->load->view('footer');
	}
	
	public function add()
	{
		if($this->Mymodel->check_subscription_exist() > 0){
			//return true;
		}else{
			redirect(base_url('subscription'));
		}
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Create an Event',
			'subpage' => 'event',
		);
		$userId = $this->session->userdata('loguserId');
        $data['get_cohost'] = $this->Mymodel->get_multiple_row_info('id, fname, lname', 'users', 'status = "1" and id != '.@$userId.'', 'id DESC', '');
		
		$this->load->view('header', $data);
		$this->load->view('account/add_event');
		$this->load->view('footer');
	}
	
	function addEvent(){
		$userId = $this->session->userdata('loguserId');
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$this->form_validation->set_rules('event_name', 'Event Name', 'required|trim'); 
			$this->form_validation->set_rules('event_description', 'Event Description', 'required|trim');
			$this->form_validation->set_rules('event_address', 'Event Address', 'required|trim');
			$this->form_validation->set_rules('event_price', 'Event Price', 'required|trim');
			$this->form_validation->set_rules('event_date', 'Event Date', 'required|trim');
			$this->form_validation->set_rules('event_time', 'Event Time', 'required|trim');
			//$this->form_validation->set_rules('event_participant', 'No. of Event Participanr', 'required|trim|numeric');
			if($this->form_validation->run() == true){
				if(!empty($_FILES['event_image']['name']) && count($_FILES['event_image']['name']) > 0){
					
					 $filesCount = count($_FILES['event_image']['name']); 
						for($i = 0; $i < $filesCount; $i++){
							$_FILES['file']['name']     = $_FILES['event_image']['name'][$i]; 
							$_FILES['file']['type']     = $_FILES['event_image']['type'][$i]; 
							$_FILES['file']['tmp_name'] = $_FILES['event_image']['tmp_name'][$i]; 
							$_FILES['file']['error']     = $_FILES['event_image']['error'][$i]; 
							$_FILES['file']['size']     = $_FILES['event_image']['size'][$i]; 
							$config['upload_path'] = 'uploads/event'; 
							$config['allowed_types'] = 'jpg|png|jpeg|gif';
							$this->load->library('upload', $config);
							$this->upload->initialize($config);
							if (!$this->upload->do_upload('file')) {
								$array = array('vali_error' => 1, 'event_image_err' => $this->upload->display_errors());
								echo json_encode($array);
								exit();
							}else{  
								$fileData = $this->upload->data();
								$uploadData[$i]['image'] = $fileData['file_name']; 
								$uploadData[$i]['userId'] = $userId; 
							} 
						}
						//print_r($uploadData);die;
						if(!empty($uploadData)){
							$data = array(
								'event_name' => strip_tags($this->input->post('event_name')),
								'event_description' => $this->input->post('event_description'),
								'event_address' => strip_tags($this->input->post('event_address')),
								'event_latitude' => strip_tags($this->input->post('event_latitude')),
								'event_longitude' => strip_tags($this->input->post('event_longitude')),
								'event_country' => strip_tags($this->input->post('event_country')),
								'event_state' => strip_tags($this->input->post('event_state')),
								'event_city' => strip_tags($this->input->post('event_city')),
								'event_zipcode' => strip_tags($this->input->post('event_zipcode')),
								'event_date' => date('Y-m-d', strtotime($this->input->post('event_date'))),
								'event_time' => date('h:i A', strtotime($this->input->post('event_time'))),
								'event_price' => $this->input->post('event_price'),
								'co_host_id' => $this->input->post('co_host'),
								//'event_participant' => strip_tags($this->input->post('event_participant')),
								'status' => '1',
								'user_id' => $userId,
								'slug' => url_title(strip_tags($this->input->post('event_name')), 'dash', true),
								'created_at'   => date('Y-m-d H:i:s')
							);
							$result= $this->Mymodel->add('event', $data);
							if(!empty($result)){
								$eventId = $result;
								$result = $this->Mymodel->add_multiple_listing_gallery($uploadData, 'event_gallery', $eventId);
								
								$response['eventId'] = $eventId;
								$response['status'] = 1;
								$response['message'] = 'Your event added successfully.';
							}else{
								$response['status'] = 0;
								$response['message'] = 'Some error ocure.Please try again.';
							}
						}
					
					
				}else{
					$array = array('vali_error' => 1, 'event_image_err' => 'Event image is required.');
					echo json_encode($array);
					exit();
				}
			}else{
				$response = array(
					'vali_error'   => 1,
					'event_name_err' => form_error('event_name'),
					'event_description_err' => form_error('event_description'),
					'event_address_err' => form_error('event_address'),
					'event_price_err' => form_error('event_price'),
					'event_date_err' => form_error('event_date'),
					'event_time_err' => form_error('event_time'),
					//'event_participant_err' => form_error('event_participant'),
				);
			}
		}
		echo json_encode($response);
	}
	
	public function details()
	{
		
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Event Details',
			'subpage' => 'event',
		);
        
		if(empty($_GET['eId'])){
			return false;
		}
		
		$query = $this->db->query("select * from event where event_id = ".base64_decode(@$_GET['eId'])." ORDER BY event_id DESC");
		$data['event'] = ($query->num_rows() > 0) ? $query->row() : FALSE;
		
		$this->load->view('header', $data);
		$this->load->view('account/event_details');
		$this->load->view('footer');
	}
	
	public function edit()
	{
		
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Update Events',
			'subpage' => 'event',
		);
		
		if(empty($_GET['eId'])){
			return false;
		}
		$userId = $this->session->userdata('loguserId');
		
        $query = $this->db->query("select * from event where event_id = ".base64_decode(@$_GET['eId'])." ORDER BY event_id DESC LIMIT 1");
		$data['event'] = ($query->num_rows() > 0) ? $query->row() : FALSE;
		
		$data['get_cohost'] = $this->Mymodel->get_multiple_row_info('id, fname, lname', 'users', 'status = "1" and id != '.@$userId.'', 'id DESC', '');
		
		$this->load->view('header', $data);
		$this->load->view('account/edit_event');
		$this->load->view('footer');
	}
	
	function editEvent(){
		$userId = $this->session->userdata('loguserId');
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$this->form_validation->set_rules('event_name', 'Event Name', 'required|trim'); 
			$this->form_validation->set_rules('event_description', 'Event Description', 'required|trim');
			$this->form_validation->set_rules('event_address', 'Event Address', 'required|trim');
			$this->form_validation->set_rules('event_price', 'Event Price', 'required|trim');
			$this->form_validation->set_rules('event_date', 'Event Date', 'required|trim');
			$this->form_validation->set_rules('event_time', 'Event Time', 'required|trim');
			//$this->form_validation->set_rules('event_participant', 'No. of Event Participanr', 'required|trim|numeric');
			if($this->form_validation->run() == true){
				if(!empty($_FILES['event_image']['name']) && count($_FILES['event_image']['name']) > 0){
					 $filesCount = count($_FILES['event_image']['name']); 
						for($i = 0; $i < $filesCount; $i++){
							$_FILES['file']['name']     = $_FILES['event_image']['name'][$i]; 
							$_FILES['file']['type']     = $_FILES['event_image']['type'][$i]; 
							$_FILES['file']['tmp_name'] = $_FILES['event_image']['tmp_name'][$i]; 
							$_FILES['file']['error']    = $_FILES['event_image']['error'][$i]; 
							$_FILES['file']['size']     = $_FILES['event_image']['size'][$i]; 
							$config['upload_path'] = 'uploads/event'; 
							$config['allowed_types'] = 'jpg|png|jpeg|gif';
							$this->load->library('upload', $config);
							$this->upload->initialize($config);
							if (!$this->upload->do_upload('file')) {
								$array = array('vali_error' => 1, 'event_image_err' => $this->upload->display_errors());
								echo json_encode($array);
								exit();
							}else{  
								$fileData = $this->upload->data();
								$uploadData[$i]['image'] = $fileData['file_name']; 
								$uploadData[$i]['userId'] = $userId; 
							} 
						}
						//print_r($uploadData);die;
						if(!empty($uploadData)){
							$data = array(
								'event_name' => strip_tags($this->input->post('event_name')),
								'event_description' => $this->input->post('event_description'),
								'event_address' => strip_tags($this->input->post('event_address')),
								'event_latitude' => strip_tags($this->input->post('event_latitude')),
								'event_longitude' => strip_tags($this->input->post('event_longitude')),
								'event_country' => strip_tags($this->input->post('event_country')),
								'event_state' => strip_tags($this->input->post('event_state')),
								'event_city' => strip_tags($this->input->post('event_city')),
								'event_zipcode' => strip_tags($this->input->post('event_zipcode')),
								'event_participant' => strip_tags($this->input->post('event_participant')),
								'event_date' => date('Y-m-d', strtotime($this->input->post('event_date'))),
								'event_time' => date('h:i A', strtotime($this->input->post('event_time'))),
								'event_price' => $this->input->post('event_price'),
								'co_host_id' => $this->input->post('co_host'),
								'slug' => url_title(strip_tags($this->input->post('event_name')), 'dash', true),
								'created_at'   => date('Y-m-d H:i:s')
							);
							//$result= $this->Mymodel->add('event', $data);
							$result= $this->Mymodel->update($data, 'event', array('event_id' => strip_tags($this->input->post('event_id'))));
							if(!empty($result)){
								$eventId = strip_tags($this->input->post('event_id'));
								$result = $this->Mymodel->add_multiple_listing_gallery($uploadData, 'event_gallery', $eventId);
								
								$response['status'] = 1;
								$response['message'] = 'Your event added successfully.';
							}else{
								$response['status'] = 0;
								$response['message'] = 'Some error ocure.Please try again.';
							}
						}
					
					
				}else{
					$data = array(
						'event_name' => strip_tags($this->input->post('event_name')),
						'event_description' => $this->input->post('event_description'),
						'event_address' => strip_tags($this->input->post('event_address')),
						'event_latitude' => strip_tags($this->input->post('event_latitude')),
						'event_longitude' => strip_tags($this->input->post('event_longitude')),
						'event_country' => strip_tags($this->input->post('event_country')),
						'event_state' => strip_tags($this->input->post('event_state')),
						'event_city' => strip_tags($this->input->post('event_city')),
						'event_zipcode' => strip_tags($this->input->post('event_zipcode')),
						'event_date' => date('Y-m-d', strtotime($this->input->post('event_date'))),
						'event_time' => date('h:i A', strtotime($this->input->post('event_time'))),
						'event_price' => $this->input->post('event_price'),
						'co_host_id' => $this->input->post('co_host'),
						//'event_participant' => strip_tags($this->input->post('event_participant')),
						'slug' => url_title(strip_tags($this->input->post('event_name')), 'dash', true),
						'created_at'   => date('Y-m-d H:i:s')
					);
					$result= $this->Mymodel->update($data, 'event', array('event_id' => strip_tags($this->input->post('event_id'))));
					if(!empty($result)){
						
						$response['status'] = 1;
						$response['message'] = 'Your event updated successfully.';
					}else{
						$response['status'] = 0;
						$response['message'] = 'Some error ocure.Please try again.';
					}
				}
			}else{
				$response = array(
					'vali_error'   => 1,
					'event_name_err' => form_error('event_name'),
					'event_description_err' => form_error('event_description'),
					'event_address_err' => form_error('event_address'),
					'event_price_err' => form_error('event_price'),
					'event_date_err' => form_error('event_date'),
					'event_time_err' => form_error('event_time'),
					//'event_participant_err' => form_error('event_participant'),
				);
			}
		}
		echo json_encode($response);
	}
	
	function loadAllevent(){
		$newre = '';
        //$displayStar = '';
		//$userGoogleAdd = $this->Mymodel->userlatLong();
		if(!empty($_GET['lastId'])){
		    $lastId = $_GET['lastId'];
			$userId = $this->session->userdata('loguserId');
		    $user_email = $this->Mymodel->get_single_row_info('email', 'users', 'id='.$userId.'', '', 1);
	
				$query = $this->db->query("select * from event where event_id < ".$lastId." and status = '1' and (user_id = ".$userId." OR event_id IN(select event_id from event_invited_people where email = '".$user_email->email."')) ORDER BY event_id DESC LIMIT 4");
				
				$event = ($query->num_rows() > 0) ? $query->result():FALSE;
				if (is_array($event) || is_object($event)) {
					foreach($event as $k => $v){
					   $gallerySql = $this->db->query("select image from event_gallery where event_id = ".@$v->event_id." ORDER BY id DESC LIMIT 1")->row();
					   $eventImg = (!empty(@$gallerySql->image) ? base_url('uploads/event/'.@$gallerySql->image.'') : base_url('uploads/noimage.jpg'));
						$newre .='
							<div class="event-list-item event-list d-lg-flex align-items-center post-item" relid="'.$v->event_id.'">
								<div class="event-img">
									<a href="'.base_url('event/details?eId='.base64_encode(@$v->event_id).'').'"><img src="'.@$eventImg.'" alt="" style="width: 400px;height: 240px;"></a>
									<span class="cat">Featured</span>
								</div>
								<div class="event-list-content">
									<h3 class="title"><a href="'.base_url('event/details?eId='.base64_encode(@$v->event_id).'').'">'.@$v->event_name.'</a></h3>
									<div class="meta-data">
									<span><i class="far fa-clock"></i> '.@$v->event_time.'</span>
									<span><i class="fas fa-map-marker-alt"></i>'.@$v->event_address.'</span>
									</div>
									<div class="event-desc">
									    <p>'.substr(@$v->event_description,0,200).'</p>
									</div>
									<a class="ticket-link" href="'.base_url('event/details?eId='.base64_encode(@$v->event_id).'').'">View Details</a>
								</div>
							</div>
						';
					}
				}
	
	    }
		echo $newre;
	}
	
	function my_event(){
		$data = array(
			'title' => 'Made to Split',
			'page' => 'My Event List',
			'subpage' => 'event',
		);
		$userId = $this->session->userdata('loguserId');
        $query = $this->db->query("select * from event where user_id = ".$userId." ORDER BY event_id DESC LIMIT 2");
		$data['event'] = ($query->num_rows() > 0) ? $query->result() : FALSE;
		
		$query = $this->db->query("select * from event where user_id = ".$userId." ORDER BY event_id DESC");
		$data['eventCount'] = ($query->num_rows() > 0) ? $query->num_rows() : FALSE;
		
		$this->load->view('header', $data);
		$this->load->view('account/my_event');
		$this->load->view('footer');
	}
	
	function loadMyevent(){
		$userId = $this->session->userdata('loguserId');
		$newre = '';
        //$displayStar = '';
		//$userGoogleAdd = $this->Mymodel->userlatLong();
		if(!empty($_GET['lastId'])){
		    $lastId = $_GET['lastId'];	
				$query = $this->db->query("select * from event where event_id < ".$lastId." and user_id = ".$userId." ORDER BY event_id DESC LIMIT 4");
				$event = ($query->num_rows() > 0) ? $query->result():FALSE;
				if (is_array($event) || is_object($event)) {
					foreach($event as $k => $v){
						
					   $gallerySql = $this->db->query("select image from event_gallery where event_id = ".@$v->event_id." ORDER BY id DESC LIMIT 1")->row();
					   $eventImg = (!empty(@$gallerySql->image) ? base_url('uploads/event/'.@$gallerySql->image.'') : base_url('uploads/noimage.jpg'));
						$newre .='
							<div class="event-list-item event-list d-lg-flex align-items-center post-item" relid="'.$v->event_id.'">
								<div class="event-img">
									<a href="'.base_url('event/details?eId='.base64_encode(@$v->event_id).'').'"><img src="'.@$eventImg.'" alt="" style="width: 400px;height: 240px;"></a>
									<span class="cat">Featured</span>
								</div>
								<div class="event-list-content">
									<h3 class="title"><a href="'.base_url('event/details?eId='.base64_encode(@$v->event_id).'').'">'.@$v->event_name.'</a></h3>
									<div class="meta-data">
									<span><i class="far fa-clock"></i> '.@$v->event_time.'</span>
									<span><i class="fas fa-map-marker-alt"></i>'.@$v->event_address.'</span>
									</div>
									<div class="event-desc">
									    <p>'.substr(@$v->event_description,0,200).'</p>
									</div>
									<a class="ticket-link" href="'.base_url('event/details?eId='.base64_encode(@$v->event_id).'').'">View Details</a><br/><br/>
									<div class="meta-data">
										<span style="margin-left: 10px;font-size: 15px;"><a href="'.base_url('event/edit?eId='.base64_encode(@$v->event_id).'').'" title="Edit"><i class="far fa-edit"></i> </a></span>
										<span style="margin-left: 10px;font-size: 15px;"><a href="javascript:void(0);" title="Delete"  onclick="deleteMyevent('.@$v->event_id.')"><i class="fas fa-trash"></i></a> </span>
									</div>
								</div>
							</div>
						';
					}
				}
	
	    }
		echo $newre;
	}
	function deleteGallery(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$id = $this->input->post('id');
			$deleteQuery = $this->db->query("delete from event_gallery where id = ".$id."");
			if($deleteQuery){
				echo 1;
			}else{
				echo 0;
			}
		}
	}
	
	function invite_people(){
		if(empty(@$_GET['eId'])){
			return false;
		}
		//echo $this->Mymodel->check_monthly_invitepeople_limit();die;
		//$userId = $this->session->userdata('loguserId');
		//get event user id
		$event_user_id = $this->Mymodel->get_single_row_info('user_id', 'event', 'event_id='.@$_GET['eId'].'', '', 1);
		$userId = $event_user_id->user_id;
		if($this->Mymodel->check_monthly_invitepeople_limit($userId) == '0'){
			// echo 'Limit is over for this month.';
			 //exit();
			if(!empty($this->session->flashdata('msg'))){
				$suc_invite_msg = $this->session->flashdata('msg');
			}else{
				$suc_invite_msg = '';
			}
			$msg = 'Your limit is over for this month.';
			$title = 'Limit Over';
			redirect(base_url('event/sub_over?msg='.$msg.'&title='.$title.'&suc_msg='.$suc_invite_msg.''));
		}elseif($this->Mymodel->check_monthly_invitepeople_limit($userId) == 'free_limit_over'){
			 //echo 'Your free subscription invited people limit is over.';
			 //exit();
			if(!empty($this->session->flashdata('msg'))){
				$suc_invite_msg = $this->session->flashdata('msg');
			}else{
				$suc_invite_msg = '';
			}
			$msg = 'Your free subscription invited people limit is over.';
			$title = 'Limit Over';
			redirect(base_url('event/sub_over?msg='.$msg.'&title='.$title.'&suc_msg='.$suc_invite_msg.''));
		}elseif($this->Mymodel->check_monthly_invitepeople_limit($userId) == 'sub_over'){
			$msg = 'Your subscription plan is expired now.';
			$title = 'Subscription Expired';
			redirect(base_url('event/sub_over?msg='.$msg.'&title='.$title.''));
		}else{
			
		}
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			
			$this->form_validation->set_rules('event_id', 'event Id', 'required|trim');
			if($this->form_validation->run() == true){
				//print_r($_POST);die;
				$event_id = $this->input->post('event_id');
				$subscription = $this->input->post('subscription');
				$email = array_filter($this->input->post('email'));
				//echo count($email);die;
				$query = $this->db->query("select * from event where event_id = ".$event_id."");
				if($query->num_rows() > 0){
					$event = $query->row();
					
					/*$existUser = $this->Mymodel->exist_invite_peoplecount($event_id);
					if($existUser > 0){
						$count = count(@$email) + $existUser;
						$amount = @$event->event_price / $count;
					}else{
						$count = count(@$email);
						$amount = @$event->event_price / $count;
					}*/
					
					$check_customize_payment = $this->Mymodel->get_single_row_info('customize_payment', 'users', 'id='.$userId.'', '', 1);
					
					if($check_customize_payment->customize_payment == 1){
						
						$countemail = count(array_filter(@$_POST['email']));
						array_filter(@$_POST['amount']);
						for($i=0;$i<$countemail;$i++){
							$email = $_POST['email'][$i];
							$amount = $_POST['amount'][$i];
							$insert_distrubuted_price[] = $this->db->query("INSERT INTO event_invited_people (email, event_id, distributed_event_price, user_id, status, invited_people, created_at)VALUES ('".@$email."', ".@$event_id.", ".@$amount.", ".@$userId.", '1', '".@$subscription."', '".date('Y-m-d H:i:s')."')");

						}
						if(!empty(@$insert_distrubuted_price)){
							$userInfo = $this->db->query("select fname, lname from users where id = ".@$event->user_id."")->row();
							$from = ucfirst(@$userInfo->fname) .' '. ucfirst(@$userInfo->lname);
							$subject = "You've been invited to (".@$event->event_name.")";
							$date = $event->event_date.' '.$event->event_time;
							for($i=0;$i<$countemail;$i++){
								$email = $_POST['email'][$i];
								$amount = $_POST['amount'][$i];
								$this->sendMail($email, $event->event_name, $from, $amount, $subject, $date);
							}
							
							//$msg = '["You have invited people successfully.", "success", "#A5DC86"]';
							$msg = 'You have invited people successfully.';
							$this->session->set_flashdata('msg', $msg);
							//echo $this->session->flashdata('msg');die;
							//redirect(base_url('event/invite-people?eId='.$event_id.''));
							redirect(base_url('event/details?eId='.base64_encode($event_id).''),'refresh');
						}
						
					}else{
					
						//$amount = @$event->event_price / @$event->event_participant;
						
						$existUser = $this->Mymodel->exist_invite_peoplecount($event_id);
						if($existUser > 0){
							$count = count(@$email) + $existUser;
							$amount = @$event->event_price / $count;
						}else{
							$count = count(@$email);
							$amount = @$event->event_price / $count;
						}
						
						$userInfo = $this->db->query("select fname, lname from users where id = ".@$event->user_id."")->row();
						$from = ucfirst(@$userInfo->fname) .' '. ucfirst(@$userInfo->lname);
						$result = $this->Mymodel->addInvitedPeople($email, $event_id, $amount, $subscription);
						
						
						if($result){
							$this->Mymodel->update_price($event_id, $amount);
							$subject = "You've been invited to (".@$event->event_name.")";
							$date = $event->event_date.' '.$event->event_time;
							if(!empty($email) && $email != ''){
								foreach($email as $k => $v){
									if(!empty($v) && $v != ''){
										$this->sendMail($v, $event->event_name, $from, $amount, $subject, $date);
									}else{
										break;
									}
								}
							}
							//$msg = '["You have invited people successfully.", "success", "#A5DC86"]';
							$msg = 'You have invited people successfully.';
							$this->session->set_flashdata('msg', $msg);
							//redirect(base_url('event/invite-people?eId='.$event_id.''),'refresh');
							redirect(base_url('event/details?eId='.base64_encode($event_id).''),'refresh');
						}
				    }	
				}
			}
		}
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Invite People',
			'subpage' => 'event',
		);
        
		$data['check_custoPay'] = $this->Mymodel->get_single_row_info('customize_payment', 'users', 'id='.$userId.'', '', 1);
		$this->load->view('header', $data);
		$this->load->view('account/invite_people');
		$this->load->view('footer');
	}
	function sendMail($email = '', $event_name, $from, $amount, $subject, $date){
		require_once APPPATH.'third_party/email/vendor/autoload.php';
		$from_email = "info@madetosplit.com"; 
		$imagePath = base_url() . 'uploads/logos/logo.png';
		$imagebackPath = '';
		$mesg = "<!Doctype html>
		<html>
			<head>
				<meta charset='utf-8'>
				<meta name='viewport' content='width=device-width, initial-scale=1'>
				<title>Invite People</title>
				<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
				</head>
			<body>
				<div style='max-width:600px;
				margin:auto;
				border:1px solid #eee;
				box-shadow:0 0 10px rgba(0, 0, 0, .15);
				line-height:17px;
				font-size:13px;
				box-sizing:border-box; -webkit-print-color-adjust: exact;font-family: Poppins, sans-serif; background:url(".$imagebackPath.")'>
					<div style='padding:20px; box-sizing: border-box;text-align: center; background: #fff;'>
					    <a href='#'><img src='".$imagePath."' style='width: 350px; height80px;'></a>
					</div>
					<div style='width: 400px; margin:50px auto;background: #ffffffd1;padding: 50px;text-align: center;'>
						<h1 style=' font-size: 30px; line-height: 32px; color: #0b0b0b; margin: 30px 0;'>Dear User</h1>
						<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;'>You have invited for <strong>".$event_name."</strong> event from <strong>".@$from." </strong></p>
						
						<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;'>Event date : <strong>".$date."</strong></p>
						
						<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;'>Event Price <strong>$".$amount."</strong>/Person</p>
						<a href='".base_url('login')."' >Register</a>
					</div>
					
					<div style='background: #000;
					text-align: left;
					box-sizing: border-box;
					width: 100%;
					padding: 20px 50px;
					color: #fff;'>
						<p style='margin: 5px 0;font-size: 12px;'>Warm Regards,</p>
						<p style='margin: 5px 0;font-size: 12px;'>Made to Split</p>
						<p style='margin: 5px 0;font-size: 12px;'><strong>Email:</strong> <a href='#' style='color: #78daff;'>info@madetosplit.com</a></p>
						<br/>
						<p style='margin: 5px 0;font-size: 11px;'>This is an automated response, please do not reply.</p>
					</div>
				</div>
			</body>
		</html>";

		$mail = new PHPMailer();
		$mail->SMTPDebug = 0;                               // Enable verbose debug output
		$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
		$mail->IsSMTP();
		$mail->SMTPAuth = true;                               // Enable SMTP authentication
		$mail->Username = 'rameshwebdev21@gmail.com';                
		$mail->Password = 'gqbtiijrzaljwkhz';
		$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		$mail->Port = 587;                                    // TCP port to connect to
		$mail->setFrom('info@madetosplit.com');
		$mail->addAddress($email);
		$mail->isHTML(true);                                  // Set email format to HTML
		$mail->Subject = @$subject;
		$mail->Body    = $mesg;
		return $mail->send();
	}
	
	
	
	// function check_subscription_exist(){
		// $userId = $this->session->userdata('loguserId');
		// $current_date = date('Y-m-d H:i:s');
		// $query = $this->db->query("select * from transaction where user_id = ".@$userId." and payment_type = '1' and end_date >= '".@$current_date."' ORDER BY id DESC LIMIT 1");
		// $result = ($query->num_rows() > 0) ? $query->num_rows() : '';
		// return $result;
	// }
	
	function check_invite_limit(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$email = array_filter($this->input->post('email'));
			$count_email = count($email);
			//$userId = $this->session->userdata('loguserId');
			//echo $this->Mymodel->count_invite_people_byuser($userId);die;
			
			$event_user_id = $this->Mymodel->get_single_row_info('user_id', 'event', 'event_id='.@$this->input->post('event_id').'', '', 1);
		    $userId = $event_user_id->user_id;
		
			$current_date = date('Y-m-d H:i:s');
			
			
				$check_subscription = $this->db->query("select id, sub_id, subscription from transaction where user_id = ".$userId." ORDER BY id DESC LIMIT 1")->row();
				if(!empty(@$check_subscription)){
					if(@$check_subscription->subscription == 'Free'){
						$count_invite_people_byuser_freesub = $this->Mymodel->count_invite_people_byuser_freesub($userId);
						$getSub = $this->db->query("select * from subscription where id = ".@$check_subscription->sub_id." and status = '1'")->row();
						if($getSub->invitation_limit <= $count_invite_people_byuser_freesub){
						    $result = 0;
							$response['limt_over'] = $result;
						}else{
						    $result = 1;
							$response['limt_over'] = $result;
							
							$count_invit_people = !empty($this->Mymodel->count_invite_people_byuser_freesub($userId)) ? $this->Mymodel->count_invite_people_byuser_freesub($userId) : 0;
							$all_email_count = $count_invit_people + $count_email;
							if($getSub->invitation_limit < $all_email_count){
								//$cal_limit = $all_email_count - $getSub->invitation_limit;
								$cal_limit = $getSub->invitation_limit - $count_invit_people;
								$response['cal_limit'] = $cal_limit;
							}else{
							    $response['cal_limit_over'] = 0;
							}
						}
					}else{
						$query = $this->db->query("select sub_id from transaction where user_id = ".$userId." and payment_type = '1' and end_date >= '".@$current_date."' ORDER BY id DESC LIMIT 1");
						if($query->num_rows() > 0){
							$sub = $query->row();
							$getSub = $this->db->query("select * from subscription where id = ".@$sub->sub_id." and status = '1'")->row();
							$sub_limit = $getSub->invitation_limit;
							if($getSub->invitation_limit <= $this->Mymodel->count_invite_people_byuser($userId)){
								//echo 'your monthly limit is over. limit is: '.@$getSub->invitation_limit.'';
								$result = 0;
								$response['limt_over'] = $result;
							}else{
								// //echo 'not over monthly limit';
								// $result = 1;
								$result = 1;
								$response['limt_over'] = $result;
								$count_invit_people = !empty($this->Mymodel->count_invite_people_byuser($userId)) ? $this->Mymodel->count_invite_people_byuser($userId) : 0;
								$all_email_count = $count_invit_people + $count_email;
								if($getSub->invitation_limit < $all_email_count){
									//$cal_limit = $all_email_count - $getSub->invitation_limit;
									$cal_limit = $getSub->invitation_limit - $count_invit_people;
									$response['cal_limit'] = $cal_limit;
								}else{
									$response['cal_limit_over'] = 0;
								}
							}
							
						}else{
							$response['no_data'] = 'not record available';
						}
					}
				}
				
			
			
			
		}
		echo json_encode($response);
	}
	
	
	function check_invite_limit_amount(){
		
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			
			$email = array_filter($this->input->post('email'));
			$count_email = count($email);
			//$userId = $this->session->userdata('loguserId');
			//echo $this->Mymodel->count_invite_people_byuser($userId);die;
			$event_user_id = $this->Mymodel->get_single_row_info('user_id', 'event', 'event_id='.@$this->input->post('event_id').'', '', 1);
			//print_r($event_user_id);die;
		    $userId = $event_user_id->user_id;
			$current_date = date('Y-m-d H:i:s');
			
			$check_subscription = $this->db->query("select id, sub_id, subscription from transaction where user_id = ".$userId." ORDER BY id DESC LIMIT 1")->row();
			if(!empty(@$check_subscription)){
				if(@$check_subscription->subscription == 'Free'){
					
					$amount = array_filter($this->input->post('amount'));
					$clientamount = array_sum($amount);
				
				    $total_amount_sum = $this->Mymodel->total_sum(@$this->input->post('event_id'));
					$total_event_amount = $clientamount + $total_amount_sum->totalAmount;
						
					$count_invite_people_byuser_freesub = $this->Mymodel->count_invite_people_byuser_freesub($userId);
					$eventPrice = $this->Mymodel->get_single_row_info('event_price', 'event', 'event_id='.@$this->input->post('event_id').'', '', 1);
					//if(@$clientamount <= @$eventPrice->event_price){
					if(@$total_event_amount <= @$eventPrice->event_price){
						$getSub = $this->db->query("select * from subscription where id = ".@$check_subscription->sub_id." and status = '1'")->row();
						
						if($getSub->invitation_limit <= $count_invite_people_byuser_freesub){
							$result = 0;
							$response['limt_over'] = $result;
						}else{
							$result = 1;
							$response['limt_over'] = $result;
							
							$count_invit_people = !empty($this->Mymodel->count_invite_people_byuser_freesub($userId)) ? $this->Mymodel->count_invite_people_byuser_freesub($userId) : 0;
							$all_email_count = $count_invit_people + $count_email;
							if($getSub->invitation_limit < $all_email_count){
								//$cal_limit = $all_email_count - $getSub->invitation_limit;
								$cal_limit = $getSub->invitation_limit - $count_invit_people;
								$response['cal_limit'] = $cal_limit;
							}else{
								$response['cal_limit_over'] = 0;
							}
						}
					}else{
						$response['large_amount'] = 'Your have enter distributed amount greater than event amount. Please enter small amount.';
					}
				}else{
					$query = $this->db->query("select sub_id from transaction where user_id = ".$userId." and payment_type = '1' and end_date >= '".@$current_date."' ORDER BY id DESC LIMIT 1");
					if($query->num_rows() > 0){
						$sub = $query->row();
						
						$amount = array_filter($this->input->post('amount'));
						$clientamount = array_sum($amount);
						
						$total_amount_sum = $this->Mymodel->total_sum(@$this->input->post('event_id'));
						$total_event_amount = $clientamount + $total_amount_sum->totalAmount;
						//echo $total_event_amount;die;
						$eventPrice = $this->Mymodel->get_single_row_info('event_price', 'event', 'event_id='.@$this->input->post('event_id').'', '', 1);
						//if(@$clientamount <= @$eventPrice->event_price){
						if(@$total_event_amount <= @$eventPrice->event_price){
							$getSub = $this->db->query("select * from subscription where id = ".@$sub->sub_id." and status = '1'")->row();
							$sub_limit = $getSub->invitation_limit;
							if($getSub->invitation_limit <= $this->Mymodel->count_invite_people_byuser($userId)){
								//echo 'your monthly limit is over. limit is: '.@$getSub->invitation_limit.'';
								$result = 0;
								$response['limt_over'] = $result;
							}else{
								// //echo 'not over monthly limit';
								// $result = 1;
								$result = 1;
								$response['limt_over'] = $result;
								$count_invit_people = !empty($this->Mymodel->count_invite_people_byuser($userId)) ? $this->Mymodel->count_invite_people_byuser($userId) : 0;
								$all_email_count = $count_invit_people + $count_email;
								if($getSub->invitation_limit < $all_email_count){
									//$cal_limit = $all_email_count - $getSub->invitation_limit;
									$cal_limit = $getSub->invitation_limit - $count_invit_people;
									$response['cal_limit'] = $cal_limit;
								}else{
									$response['cal_limit_over'] = 0;
								}
							}
						}else{
							$response['large_amount'] = 'Your have enter distributed amount greater than event amount. Please enter small amount.';
						}

					}else{
						$response['no_data'] = 'not record available';
					}
				}
			}else{
				$response['no_data'] = 'not record available';
			}
			
			
			
		}
		echo json_encode($response);
	}
	
	function sub_over(){
		$data = array(
		'title' => 'Made to Split',
		'page' => 'Subscription and Limit Over',
		'subpage' => 'event',
		);

		$this->load->view('header', $data);
		$this->load->view('account/sub_over');
		$this->load->view('footer');
	}	
	function test(){
		$userId = $this->session->userdata('loguserId');
		echo $this->Mymodel->count_invite_people_byuser($userId);
	}
	
	function get_chat_user(){
		$html = '';
		$userId = $this->session->userdata('loguserId');
		$user_email = $this->Mymodel->get_single_row_info('email', 'users', 'id='.$userId.'', '', 1);
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$event_id = $this->input->post('event_id');
			$host_user_id = $this->input->post('host_user_id');
			$host_email = $this->Mymodel->get_single_row_info('email', 'users', 'id='.$host_user_id.'', '', 1);
			$get_invited_people = $this->db->query("select * from event_invited_people where event_id = ".@$event_id." and user_id = ".@$host_user_id." and email != '".@$user_email->email."'")->result();
			//if(!empty(@$get_invited_people)){
			
			$check_event = $this->db->query("select * from event where event_id = ".$event_id." and user_id = ".$userId."")->num_rows();
			if(@$check_event > 0){
				
			}else{
				$check_email_inevent = 	$this->db->query("select * from event_invited_people where event_id = ".@$event_id." and email = '".@$host_email->email."'")->num_rows();
				if(@$check_email_inevent > 0){

				}else{			
					$get_invited_people[] =   (object)['id' => 0,
						'email' => @$host_email->email,
						'event_id' => '',
						'distributed_event_price'=>'',
						'user_id' => '',
						'status' => '',
						'transaction' => '',
						'created_at' => '',
						'updated_at' => ''
					];
					
					
				}
			}
			
			$get_co_host = $this->Mymodel->get_single_row_info('co_host_id', 'event', 'event_id='.@$event_id.'', '', 1);
			
			if(!empty(@$get_co_host->co_host_id)){
				if(@$userId == @$get_co_host->co_host_id){
				
			    }else{
					$co_host_email = $this->Mymodel->get_single_row_info('email', 'users', 'id='.@$get_co_host->co_host_id.'', '', 1);
					$check_cohost_invited = $this->db->query("select * from event_invited_people where event_id = ".@$event_id." and email = '".@$co_host_email->email."'")->num_rows();
					
					if(@$check_cohost_invited > 0){
						
					}else{
						$get_invited_people[] =   (object)['id' => 0,
							'email' => @$co_host_email->email,
							'event_id' => '',
							'distributed_event_price'=>'',
							'user_id' => '',
							'status' => '',
							'transaction' => '',
							'created_at' => '',
							'updated_at' => ''
						];
					}
				}
			}
			
			//print_r($get_invited_people);die;
               //echo $this->db->last_query();die;
				foreach($get_invited_people as $k => $v){
					
					$get_register_user = $this->db->query("select id, fname, lname, email, image from users where (email = '".$v->email."' )  and status = '1'")->row();
					//print_r($get_register_user);die;
					
					if(!empty(@$get_register_user)){
						$msgCount = $this->countMsg($userId, $get_register_user->id);
						$html .='<div class="usermesslist" sender_id ='.@$userId.' receiver_id = '.@$get_register_user->id.'>
							<div class="d-flex align-items-center">
								<div>
									<img src="'.(!empty(@$get_register_user->image) ? base_url('uploads/profile/'.@$get_register_user->image.'') : base_url('uploads/unnamed.jpg')).'">
								</div>
								<div class="ps-2 flex-fill">
									<h3>'.@$get_register_user->fname .' '. @$get_register_user->lname.'</h3>
									<p>'.((@$host_email->email == $get_register_user->email) ? 'Event Host' : '').'</p>
									
								</div>
								'.((!empty(@$msgCount) && (@$msgCount > 0)) ? '<div id="msgCount_'.@$get_register_user->id.'" style="background: red;margin: 0px 171px;width: 25px;padding: 0px 10px;border-radius: 61px;color: white;font-size: 14px;font-weight: 900;position: absolute;">'.@$msgCount.'</div>' : '').'
								
								
								<div>
									<input type="checkbox" name="">
								</div>
							</div>
						</div>
						<div class="gropchtbtn">
						    <a href="javascript:void(0)" class="btn btn-primary btn-sm user_group_chat" sender_id ='.@$userId.' host_user_attr="'.@$host_user_id.'">Group Chat</a>
						</div>
						';
					}
				}
			//}
		}
		echo $html;
	}
	function countMsg($receiverId = '', $senderId = ''){

		    $select = "SELECT * FROM chat where receiver_id = ".$receiverId." and sender_id = ".$senderId." and status = '1' and group_msg IS NULL"; 
			$query = $this->db->query($select);
			$row = ($query->num_rows() > 0) ? $query->num_rows() : FALSE; 
			return $row;
	}
	function get_personal_chat(){
		$html = '';
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$sender_id = $this->input->post('sender_id');
			$receiver_id = $this->input->post('receiver_id');
			$event_id = $this->input->post('event_id');
			$get_receiver_info = $this->Mymodel->get_single_row_info('fname, lname, image', 'users', 'id='.$receiver_id.'', '', 1);
			$html .='	
			<div class="sidemessage-header d-flex justify-content-between align-items-center">
                <div>
                    <a href="#"><img src="'.(!empty(@$get_receiver_info->image) ? base_url('uploads/profile/'.@$get_receiver_info->image.'') : base_url('uploads/unnamed.jpg')).'">'.@$get_receiver_info->fname .' '. @$get_receiver_info->lname.'</a>
                </div>
                <div>
                    <ul class="listmsgheader">
                        <li><a href="#" class="closemsg"><i class="fa fa-times"></i></a></li>
                    </ul>
                </div>
            </div>
			
            <div class="sidemessage-body specific_preview" id="latest_insert_chat">
			
                
				'.$this->display_chat($sender_id, $receiver_id, $event_id).'
               
				
            </div>
				';
		}
		$response['html'] = $html;
		$response['sender_id'] = $sender_id;
		$response['receiver_id'] = $receiver_id;
		echo json_encode($response);
	}
	function display_chat($sender_id = '', $receiver_id = '', $event_id ){
		$output = '';
		$userId = $this->session->userdata('loguserId');
		
		$chat_query = $this->db->query("select * from chat where (sender_id = ".@$sender_id." and receiver_id = ".@$receiver_id." and event_id = ".$event_id." and group_msg IS NULL) OR (sender_id = ".@$receiver_id." and receiver_id = ".@$sender_id." and event_id = ".$event_id." and group_msg IS NULL) ");
		$result = ($chat_query->num_rows() > 0) ? $chat_query->result() : '';
		
		$sender_user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.@$sender_id.'', '', 1);
		$receiver_user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.@$receiver_id.'', '', 1);
		if (is_array($result) || is_object($result)) {
			foreach($result as $k => $v){
				
				if(@$v->sender_id == @$userId){
					
					$output .='<div class="outgoing_msg d-flex justify-content-end">
						<div class="messageinnerimg order-2">
							<img src="'.(!empty(@$sender_user_image->image) ? base_url('uploads/profile/'.@$sender_user_image->image.'') : base_url('uploads/unnamed.jpg')).'" alt="">
						</div>
						<div class="sent_msg">
						  <div>
							<p>'.@$v->message.'</p>
							
							<span class="time_date text-right mt-0">'.date('M d Y', strtotime(@$v->created_at)).' | '.date('h:i A', strtotime(@$v->created_at)).'</span>
							'.$this->check_file($v->image).'
							
							
						  </div>
						</div>
					</div>';
				}else{
					
					//echo $this->db->last_query();
					$output .='<div class="incoming_msg d-flex justify-content-start">
						<div class="messageinnerimg">
							<img src="'.(!empty(@$receiver_user_image->image) ? base_url('uploads/profile/'.@$receiver_user_image->image.'') : base_url('uploads/unnamed.jpg')).'" alt="">
						</div>
						<div class="sent_msg">
						  <div>
							<p>'.@$v->message.'</p>
							<span class="time_date text-right mt-0">'.date('M d Y', strtotime(@$v->created_at)).' | '.date('h:i A', strtotime(@$v->created_at)).'</span>
							'.$this->check_file($v->image).'
						  </div>
						</div>
					</div>';
				}
				
			}
	    }
		return $output;
	}
	
	function check_file($file = ''){
		$result = '';
		if(!empty($file)){
			$explodeFile = explode('.', $file);
			//if($explodeFile[1] == 'jpg' OR $explodeFile[1] == 'jpeg' OR $explodeFile[1] == 'png'){
				//$result.= '<img src="'.base_url('uploads/chat/dot-box2.png').'" style="width:40%">';
				$result.= '<div id="filename"><div id="file_0"><span class="fa-stack fa-lg"><i class="fa fa-file fa-stack-1x "></i><strong class="fa-stack-1x" style="color:#FFF; font-size:12px; margin-top:2px;"></strong></span> <span style="font-size:15px;font-weight:800">'.@$file.'</span>&nbsp;&nbsp;<a href="'.base_url('uploads/chat/'.@$file.'').'" download><span class="fa fa-download"></span></a></div></div>';
			//}
			
		}
		return $result;
	}
	function send_message(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			
			$this->form_validation->set_rules('sender_id', 'Sender Id', 'required|trim|numeric');
			$this->form_validation->set_rules('receiver_id', 'Receiver Id', 'required|trim|numeric');
			$this->form_validation->set_rules('event_id', 'Event Id', 'required|trim|numeric');
			//$this->form_validation->set_rules('message', 'Message', 'required|trim');
			if($this->form_validation->run() == true){
				
				if(!empty($_FILES['image']['name'])){
					$config['upload_path'] = 'uploads/chat'; # check path is correct
					$config['allowed_types'] = 'pdf|jpg|png|jpeg|docx|xlsx|csv'; # add video extenstion on here
					$config['overwrite'] = FALSE;
					$config['remove_spaces'] = TRUE;
					$image_name = preg_replace("/\s+/", "_", $_FILES['image']['name']);
					$config['file_name'] = $image_name;
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('image')) {
					$array = array('vali_error' => 1, 'product_image_err' => $this->upload->display_errors());
					echo json_encode($array);
					exit();
					}else {
						$sender_id = $this->input->post('sender_id');
						$receiver_id = $this->input->post('receiver_id');
						$event_id = $this->input->post('event_id');
						$message = $this->input->post('message');
						$data = array('sender_id' => $sender_id, 'receiver_id' => $receiver_id, 'event_id' => $event_id, 'message' => $message, 'status' => '1', 'header_noti_status' => '1', 'image' => $image_name, 'created_at' => date('Y-m-d H:i:s'));
						
						$result= $this->Mymodel->add('chat', $data);
						if(!empty($result)){
							$chat_id = $result;
							$response['chat_id'] = $chat_id;
							$response['status'] = 1;
							//$response['message'] = 'Your event added successfully.';
							$chat_query = $this->db->query("select * from chat where sender_id = ".@$sender_id." and receiver_id = ".@$receiver_id." and event_id = ".@$event_id." and id = ".@$chat_id."")->row();
							
							$user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.$chat_query->sender_id.'', '', 1);
							//echo $this->db->last_query();
							
							$response['sender_image'] = !empty($user_image->image) ? base_url('uploads/profile/'.@$user_image->image.'') : base_url('uploads/unnamed.jpg');
							$response['sender_message'] = $chat_query->message;
							$response['sender_date'] = date('M d Y', strtotime($chat_query->created_at));
							$response['sender_time'] = date('h:i A', strtotime($chat_query->created_at));
							$response['sender_file'] = $image_name;
							
						}else{
							$response['status'] = 0;
							//$response['message'] = 'Some error ocure.Please try again.';
						}
					}
				}else{
					$sender_id = $this->input->post('sender_id');
					$receiver_id = $this->input->post('receiver_id');
					$event_id = $this->input->post('event_id');
					$message = $this->input->post('message');
					$data = array('sender_id' => $sender_id, 'receiver_id' => $receiver_id, 'event_id' => $event_id, 'message' => $message, 'status' => '1', 'header_noti_status' => '1', 'created_at' => date('Y-m-d H:i:s'));
					
					$result= $this->Mymodel->add('chat', $data);
					if(!empty($result)){
						$chat_id = $result;
						$response['chat_id'] = $chat_id;
						$response['status'] = 1;
						//$response['message'] = 'Your event added successfully.';
						$chat_query = $this->db->query("select * from chat where sender_id = ".@$sender_id." and receiver_id = ".@$receiver_id." and event_id = ".@$event_id." and id = ".@$chat_id."")->row();
						
						$user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.$chat_query->sender_id.'', '', 1);
						//echo $this->db->last_query();
						
						$response['sender_image'] = !empty($user_image->image) ? base_url('uploads/profile/'.@$user_image->image.'') : base_url('uploads/unnamed.jpg');
						$response['sender_message'] = $chat_query->message;
						$response['sender_date'] = date('M d Y', strtotime($chat_query->created_at));
						$response['sender_time'] = date('h:i A', strtotime($chat_query->created_at));
						$response['sender_file'] = '';
						
					}else{
						$response['status'] = 0;
						//$response['message'] = 'Some error ocure.Please try again.';
					}
				}
				
			}else{
				$response = array(
					'vali_error'   => 1,
					'sender_id_err' => form_error('sender_id'),
					'receiver_id_err' => form_error('receiver_id'),
					'event_id_err' => form_error('event_id'),
					'message_err' => form_error('message'),
				);
			}
		}
		echo json_encode($response);
	}
	
	function update_msg_noti(){
		//print_r($_POST);
		$sender_id = $this->input->post('sender_id');
		$receiver_id = $this->input->post('receiver_id');
		
		$noti_update = $this->db->query("update chat set status = '0', header_noti_status = '0' where sender_id = ".@$sender_id." and receiver_id = ".@$receiver_id." and group_msg IS NULL");
		if(!empty($noti_update)){
			$response['status'] = 1;
		}else{
			$response['status'] = 0;
		}
		echo json_encode($response);
	}
	function get_msgnotification(){
		if(!empty($this->session->userdata('loguserId'))){
			$userId = $this->session->userdata('loguserId');
			$get_chat_msg = $this->db->query("select * from chat where FIND_IN_SET($userId, receiver_id) and status = '1' and header_noti_status = '1' ORDER BY id DESC LIMIT 1")->row();
			if(!empty(@$get_chat_msg)){
				$response['status'] = 1;
				$response['chat_id'] = @$get_chat_msg->id;
				$response['event_id'] = base64_encode(@$get_chat_msg->event_id);
				$response['sender_id'] = @$get_chat_msg->sender_id;
				$response['receiver_id'] = @$get_chat_msg->receiver_id;
				$response['group_msg'] = @$get_chat_msg->group_msg;
			}else{
				$response['status'] = 0;
			}
		}else{
			$response['status'] = 0;
		}
		echo json_encode($response);
	}
	
	function updatemsg_notification(){
		$chat_id = $this->input->post('chat_id');
		$event_id = $this->input->post('event_id');
		$noti_update = $this->db->query("update chat set header_noti_status = '0' where id = ".@$chat_id." and event_id = ".base64_decode(@$event_id)."");
		if(!empty($noti_update)){
			echo 1;
		}else{
			echo 0;
		}
	}
	
	function count_allnewmsg(){
		if(!empty($this->session->userdata('loguserId'))){
			$userId = $this->session->userdata('loguserId');
			$event_id = $this->input->post('event_id');
			$get_chat_msg = $this->db->query("select * from chat where receiver_id = ".@$userId." and event_id = ".@$event_id." and status = '1' and group_msg IS NULL")->num_rows();
			if($get_chat_msg > 0){
				echo $get_chat_msg;
			}else{
				echo 0;
			}
		}else{
			echo 'current user not login.';
		}
	}
	
	function deleteMyevent($id){
		if(empty($id)){
			return false;
		}
		$deleteQuery = $this->db->query("delete from event where event_id = ".$id."");
		if(!empty($deleteQuery)){
			$this->session->set_flashdata('msg', 'Your event deleted successfully.');
			redirect('event/my-event');
		}
	}
	
	function event_participant(){
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Event and Participant',
			'subpage' => 'event',
		);
       
	   	$userId = $this->session->userdata('loguserId');
		$query = $this->db->query("select * from users where status = '1' and id = ".@$userId." ORDER BY id DESC");
		$data['user'] = ($query->num_rows() > 0) ? $query->row() : FALSE;
		
        $query = $this->db->query("select event_id, event_name, event_date, event_time, event_description, event_price from event where status = '1' and user_id = ".$userId." ORDER BY event_id DESC");
		$data['list'] = ($query->num_rows() > 0) ? $query->result() : FALSE;
		$this->load->view('header', $data);
		$this->load->view('account/event_and_participant');
		$this->load->view('footer');
	}
	
	public function fetchBank()
	{
		$response = [];
		$html = '';
		$eId = $this->input->post('eId'); 
		//$details =$this->adminmodel->fetch_row('bank', "user_id='".$userId."'");
		//$query = $this->db->query("select * from event_invited_people where event_id = ".@$eId." and status = '1'");
		$query = $this->db->query("SELECT event_invited_people.id, event_invited_people.email, event_invited_people.transaction, event_invited_people.event_id, event_invited_people.distributed_event_price, event_invited_people.user_id, event_invited_people.status, (select fname from users where email = event_invited_people.email) as fname, (select lname from users where email = event_invited_people.email) as lname, (select id from users where email = event_invited_people.email) as userId FROM event_invited_people where event_invited_people.event_id = ".@$eId."");
		$result = ($query->num_rows() > 0) ? $query->result() : '';
		$html .='<table  class="table table-bordered table-striped">
		<thead>
		<tr>
		<th>Invited Guest </th>
		<th>Email </th>
		<th>Event Amount</th>
		<th>Balance</th>
		<th>Transaction</th>
		<th>Status</th>
		</tr>
		</thead>
		<tbody>';
			if (is_array($result) || is_object($result)) {
				foreach($result as $k => $v){
					$getUser = $this->db->query("select fname, id, lname from users where email = '".@$v->email."' and status = '1'")->row();
					$userName = !empty($getUser->fname) ? @$getUser->fname .' '. @$getUser->lname : 'New User - Awaiting user registration';
					
					if(!empty(@$v->fname) || !empty(@$v->lname)){
						$status = '<div style="color: white;background: green;width: 100%;padding: 5px;font-weight: 700;border-radius: 5px;">Registered</div>';
						//$status = '<div style="color: white;background: green;width: 64%;padding: 5px;font-weight: 700;border-radius: 5px;">Not register yet.</div>';
					}else{
						$status = '<div style="color: white;background: red;width: 100%;padding: 5px;font-weight: 700;border-radius: 5px;">Not registered.</div>';
					}
					if(!empty($getUser->id)){
					    $query = $this->db->query("select sum(amount) as totalAmount from transaction where user_id = ".$getUser->id." and event_id = ".$v->event_id." and payment_type = '2' and status = 'succeeded'")->row();
						$totolAmount = $query->totalAmount;
						$balance = $v->distributed_event_price - $totolAmount;
					}else{
						$balance = $v->distributed_event_price;
						$totolAmount = 0;
					}
					if($v->distributed_event_price == $totolAmount){
						$trans_status = 'Paid';
					}elseif($totolAmount == 0){
						$trans_status = 'Not Paid';
					}elseif($balance < $v->distributed_event_price){
						$trans_status = 'Paid in Part';
					}
					
					$html .= '
					<tr>
						<td>'.@$userName.'</td>
						<td>'.$v->email.'</td>
						<td>$'.$v->distributed_event_price.'</td>
						<td>$'.number_format(@$balance, 2).'</td>
						<td>
							<select data-value="'.@$v->userId.'" relid="'.@$v->event_id.'" id_attr="'.@$v->id.'" name="sub_status" row="12px" id="sub_status" class="substatusClass form-control" style="width: 60%;height: 50px;margin: 0px 30px;border: 1px solid black;">
								<option value="">Select</option>
								<option value="Paid" '.((@$trans_status == 'Paid') ? 'selected' : '').'>Paid</option>
								<option value="Not Paid" '.((@$trans_status == 'Not Paid') ? 'selected' : '').'>Not Paid</option>
							</select><br/>
							<p style="margin: 0px 55px;">'.@$trans_status.'</p>
						</td>
						<td>'.@$status.'</td>
					</tr>
					';
				}
				$response['html'] = $html;
			}else{
				$response['html'] = 'No data found.';
			}
		$html .='</tbody>
		</table>';
		echo json_encode($response);
	}
	
	function update_event_payment(){
		//print_r($_POST);die;
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$event_id = $this->input->post('event_id');
			$user_id = $this->input->post('user_id');
			$transaction = $this->input->post('transaction');
			$id = $this->input->post('id');
			
			$get_user_count = $this->db->query("select id from users where id = ".@$user_id."")->num_rows();
			if($get_user_count > 0){
				$update_event_pay = $this->db->query("update event_invited_people set transaction = '".@$transaction."' where id = ".@$id." and event_id = ".@$event_id."");
				if($transaction == 'Paid'){
					if(!empty(@$update_event_pay)){
						
						$get_user = $this->db->query("select id, fname, lname, email, address, country, state, city, zipcode from users where id = ".@$user_id."")->row();
						$get_invited_people = $this->db->query("select distributed_event_price from event_invited_people where id = ".@$id." and event_id = ".@$event_id." ")->row();
						
						$cardholder = @$get_user->fname .' '. @$get_user->lname;
						$amount = @$get_invited_people->distributed_event_price;
						$user_id = @$user_id;
						$email =  @$get_user->email;
						$country =  @$get_user->country;
						$state =  @$get_user->state;
						$city =  @$get_user->city;
						$zipcode =  @$get_user->zipcode;
						$address = @$get_user->address;
						$currency = "USD";
						$orderID = "TEST_".$this->generate_otp(6);

						
						$tran_data = array(
							'user_name' => $cardholder, 'user_id' => $user_id, 'order_id' => $orderID, 'address' => $address, 'country' => $country, 'state' => $state, 'city' => $city, 'zipcode' => $zipcode, 'amount' => $amount, 'payment_type' => '2', 'status' => 'succeeded', 'currency' => 'usd', 'event_id' => $event_id, 'paid_by_admin' => '2', 'created_at' => date('Y-m-d H:i:s')
						);
						$result= $this->Adminmodel->add('transaction', $tran_data);
						if(!empty($result)){
							$response['status'] = 1;
							$response['message'] = 'you have added event payment successfully for this user.';
						}else{
							$response['status'] = 0;
							$response['message'] = 'some error occure.please try again.';
						}
					}
				}else{
					if(!empty(@$update_event_pay)){
						$delete_tran = $this->db->query("delete from transaction where user_id = ".@$user_id." and event_id = ".@$event_id." and payment_type = '2' and paid_by_admin = '2'");
						
						if(!empty($delete_tran)){
							$response['status'] = 1;
							$response['message'] = 'transaction deleted successfully.';
						}else{
							$response['status'] = 0;
							$response['message'] = 'some error occure.please try again.';
						}
					}
				}
			}else{
				$response['status'] = 0;
				$response['message'] = 'user not register yet.';
			}
			
		}
		echo json_encode($response);
	}
	public function generate_otp($length)
	{
		$characters = '123456789';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++)
		{
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	function email_already_exist(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$event_id = $this->input->post('event_id');
			$email = $_POST['email'];
			if(!empty($email)){
				$countemail =array_filter(@$email);
				//print_r($countemail);
				//echo $countemail;die;
				for($i = 0; $i < count($countemail); $i++){
				
                    // if($i == 0){
						// break;
					// }
					//echo 'email = '.$email[$i].'';
					$checkEmail = $this->db->query("select email from event_invited_people where email = '".$email[$i]."' and event_id = '".$event_id."'")->num_rows();
					 //echo $this->db->last_query();
					// echo $checkEmail;
					if($checkEmail > 0){
						$response['status'] = false; 
						$response['email'] = $email[$i]; 
						echo json_encode($response);
						return false;
						
					}
					
				}
				$response['status'] = true; 
				echo json_encode($response);
				return true;
			}
			  
			
		}
		
	}
	
	function remove_event_participant(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$eId = $this->input->post('eId');
			$participantId = $this->input->post('participantId');
			$userId = $this->session->userdata('loguserId');
			$remove_participant = $this->db->query("delete from event_invited_people where id = ".@$participantId."");
			if(!empty(@$remove_participant)){
				$user_pay_customize = $this->Mymodel->get_single_row_info('customize_payment', 'users', 'id='.$userId.'', '', 1);
				if($user_pay_customize->customize_payment == 0){
					$event_participant_count = $this->db->query("select email from event_invited_people where event_id = '".$eId."'")->num_rows();
					$event_price = $this->Mymodel->get_single_row_info('event_price', 'event', 'event_id='.$eId.'', '', 1);
					$distribute_amount = @$event_price->event_price / @$event_participant_count;
					$update = $this->db->query("update event_invited_people set distributed_event_price = '".@$distribute_amount."' where event_id = ".$eId."");
					
					if(!empty($update)){
						$response['status'] = 1;
						$response['message'] = 'Your event participant deleted successfully.';
					}else{
						$response['status'] = 0;
						$response['message'] = 'Some error occure,Please try again.';
					}
				}else{
					if(!empty($remove_participant)){
						$response['status'] = 1;
						$response['message'] = 'Your event participant deleted successfully.';
					}else{
						$response['status'] = 0;
						$response['message'] = 'Some error occure,Please try again.';
					}
				}

			}
		}
		echo json_encode(@$response);
	}
	
	function get_group_chat(){
		$html = '';
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$userId = $this->session->userdata('loguserId');
			$sender_id = $this->input->post('sender_id');
			$event_id = $this->input->post('event_id');
			$host_user_id = $this->input->post('host_user_attr');
			$host_email = $this->Mymodel->get_single_row_info('id, email', 'users', 'id='.$host_user_id.'', '', 1);
			//$get_receiver_info = $this->Mymodel->get_single_row_info('name, event_name, event_id', 'event', 'event_id='.$event_id.'', '', 1);
			$event_info = $this->db->query("select event_name, event_id, (select image from event_gallery where event_id = ".$event_id." LIMIT 1) as event_image from event where event_id = ".$event_id."")->row();
			$html .='	
			<div class="sidemessage-header d-flex justify-content-between align-items-center">
                <div>
                    <a href="#"><img src="'.(!empty(@$event_info->event_image) ? base_url('uploads/event/'.@$event_info->event_image.'') : base_url('uploads/noimage.jpg')).'">'.substr(@$event_info->event_name, 0, 30).'</a>
                </div>
                <div>
                    <ul class="listmsgheader">
                        <li><a href="#" class="closemsg"><i class="fa fa-times"></i></a></li>
                    </ul>
                </div>
            </div>
			
            <div class="sidemessage-body specific_preview_groupchat" id="latest_insert_groupchat">
                '.$this->display_group_chat($sender_id, $event_id).'
            </div>';
			
			
		}
		//$user_email = $this->Mymodel->get_single_row_info('id, email', 'users', 'id='.$userId.'', '', 1);
		
		//$get_invited_people = $this->db->query("select email from event_invited_people where event_id = ".@$event_id." and user_id = ".@$host_user_id." and email != '".@$user_email->email."'")->result();
		
		
		$response['html'] = $html;
		$response['sender_id'] = $sender_id;
		//$response['receiver_id'] = $receiver_id;
		$response['host_id'] = $host_email->id;
		echo json_encode($response);
	}
	function display_group_chat($sender_id, $event_id){
		
		$output = '';
		$userId = $this->session->userdata('loguserId');
		
		$chat_query = $this->db->query("select * from chat where event_id = ".$event_id." and group_msg = '1'");
		$result = ($chat_query->num_rows() > 0) ? $chat_query->result() : '';
		//print_r($result);die;
		
		$sender_user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.@$sender_id.'', '', 1);
		//$receiver_user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.@$receiver_id.'', '', 1);
		if (is_array($result) || is_object($result)) {
			foreach($result as $k => $v){
				$receiver_user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.@$v->sender_id.'', '', 1);
				if(@$v->sender_id == @$userId){
					
					$output .='<div class="outgoing_msg d-flex justify-content-end">
						<div class="messageinnerimg order-2">
							<img src="'.(!empty(@$sender_user_image->image) ? base_url('uploads/profile/'.@$sender_user_image->image.'') : base_url('uploads/unnamed.jpg')).'" alt="">
						</div>
						<div class="sent_msg">
						  <div>
							<p>'.@$v->message.'</p>
							<span class="time_date text-right mt-0">'.date('M d Y', strtotime(@$v->created_at)).' | '.date('h:i A', strtotime(@$v->created_at)).'</span>
							'.$this->check_file($v->image).'
						  </div>
						</div>
					</div>';
				}else{
					
					//echo $this->db->last_query();
					$output .='<div class="incoming_msg d-flex justify-content-start">
						<div class="messageinnerimg">
							<img src="'.(!empty(@$receiver_user_image->image) ? base_url('uploads/profile/'.@$receiver_user_image->image.'') : base_url('uploads/unnamed.jpg')).'" alt="">
						</div>
						<div class="sent_msg">
						  <div>
							<p>'.@$v->message.'</p>
							<span class="time_date text-right mt-0">'.date('M d Y', strtotime(@$v->created_at)).' | '.date('h:i A', strtotime(@$v->created_at)).'</span>
							'.$this->check_file($v->image).'
						  </div>
						</div>
					</div>';
				}
				
			}
	    }
		return $output;
	
	}
	
	function send_group_chat(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			
			$this->form_validation->set_rules('sender_id', 'Sender Id', 'required|trim|numeric');
			$this->form_validation->set_rules('host_id', 'Host Id', 'required|trim|numeric');
			$this->form_validation->set_rules('event_id', 'Event Id', 'required|trim|numeric');
			//$this->form_validation->set_rules('message', 'Message', 'required|trim');
			if($this->form_validation->run() == true){
				
				if(!empty($_FILES['image']['name'])){
					$config['upload_path'] = 'uploads/chat'; # check path is correct
					$config['allowed_types'] = 'pdf|jpg|png|jpeg|docx|xlsx|csv'; # add video extenstion on here
					$config['overwrite'] = FALSE;
					$config['remove_spaces'] = TRUE;
					$image_name = preg_replace("/\s+/", "_", $_FILES['image']['name']);
					$config['file_name'] = $image_name;
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('image')) {
					$array = array('vali_error' => 1, 'image_err' => $this->upload->display_errors());
					echo json_encode($array);
					exit();
					}else {
						$sender_id = $this->input->post('sender_id');
						$host_id = $this->input->post('host_id');
						$event_id = $this->input->post('event_id');
						$message = $this->input->post('message');
						
						$host_data = $this->Mymodel->get_single_row_info('id, email', 'users', 'id='.@$host_id.'', '', 1);
						$my_data = $this->Mymodel->get_single_row_info('id, email', 'users', 'id='.@$sender_id.'', '', 1);
						$get_invited_people = $this->db->query("select * from event_invited_people where email != '".@$my_data->email."' and event_id = ".@$event_id."")->result();
						if(!empty($get_invited_people)){
							$check_host_exist = $this->db->query("select * from event_invited_people where email = '".@$host_data->email."' and event_id = ".@$event_id."")->num_rows();
							
							if($check_host_exist > 0){
								
							}else{
								$host_receiver_id = $this->Mymodel->get_single_row_info('id, email', 'users', 'email="'.@$host_data->email.'"', '', 1);
								$get_invited_people[] = (object)[
									'id' => 0,
									'email' => @$host_receiver_id->email,
									'event_id' => '',
									'distributed_event_price'=>'',
									'user_id' => '',
									'status' => '',
									'transaction' => '',
									'created_at' => '',
									'updated_at' => ''
								];
							}
							$receiver_id = [];
							foreach($get_invited_people as $k => $v){  
								$invited_people = $this->Mymodel->get_single_row_info('id', 'users', 'email="'.@$v->email.'"', '', 1);
								if(!empty($invited_people)){
									$receiver_id[] = $invited_people->id;
								}
							}
						}
						$data = array('sender_id' => $sender_id, 'receiver_id' => implode(',', $receiver_id), 'event_id' => $event_id, 'message' => $message, 'status' => '1', 'image' => $image_name, 'header_noti_status' => '1', 'created_at' => date('Y-m-d H:i:s'), 'group_msg' => '1');
						$result= $this->Mymodel->add('chat', $data);
						
						
						if(!empty($result)){
							$chat_id = $result;
							$response['chat_id'] = $chat_id;
							$response['status'] = 1;
							$receiverId = implode(',', @$receiver_id);
							$chat_query = $this->db->query("select * from chat where sender_id = ".@$sender_id." and receiver_id = '".@$receiverId."' and event_id = ".@$event_id." and id = ".@$chat_id."")->row();
							
							$user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.$chat_query->sender_id.'', '', 1);
							//echo $this->db->last_query();
							
							$response['sender_image'] = !empty($user_image->image) ? base_url('uploads/profile/'.@$user_image->image.'') : base_url('uploads/unnamed.jpg');
							$response['sender_message'] = $chat_query->message;
							$response['sender_date'] = date('M d Y', strtotime($chat_query->created_at));
							$response['sender_time'] = date('h:i A', strtotime($chat_query->created_at));
							$response['sender_file'] = $image_name;
							
						}else{
							$response['status'] = 0;
							//$response['message'] = 'Some error ocure.Please try again.';
						}
					}
				}else{
					$sender_id = $this->input->post('sender_id');
					$host_id = $this->input->post('host_id');
					$event_id = $this->input->post('event_id');
					$message = $this->input->post('message');
					
					$host_data = $this->Mymodel->get_single_row_info('id, email', 'users', 'id='.@$host_id.'', '', 1);
					$my_data = $this->Mymodel->get_single_row_info('id, email', 'users', 'id='.@$sender_id.'', '', 1);
					$get_invited_people = $this->db->query("select * from event_invited_people where email != '".@$my_data->email."' and event_id = ".@$event_id."")->result();
					if(!empty($get_invited_people)){
						$check_host_exist = $this->db->query("select * from event_invited_people where email = '".@$host_data->email."' and event_id = ".@$event_id."")->num_rows();
						
						if($check_host_exist > 0){
							
						}else{
							$host_receiver_id = $this->Mymodel->get_single_row_info('id, email', 'users', 'email="'.@$host_data->email.'"', '', 1);
							$get_invited_people[] = (object)[
								'id' => 0,
								'email' => @$host_receiver_id->email,
								'event_id' => '',
								'distributed_event_price'=>'',
								'user_id' => '',
								'status' => '',
								'transaction' => '',
								'created_at' => '',
								'updated_at' => ''
							];
						}
						$receiver_id = [];
						foreach($get_invited_people as $k => $v){  
							$invited_people = $this->Mymodel->get_single_row_info('id', 'users', 'email="'.@$v->email.'"', '', 1);
							if(!empty($invited_people)){
								$receiver_id[] = $invited_people->id;
							}
						}
					}
					$data = array('sender_id' => $sender_id, 'receiver_id' => implode(',', $receiver_id), 'event_id' => $event_id, 'message' => $message, 'status' => '1', 'header_noti_status' => '1', 'created_at' => date('Y-m-d H:i:s'), 'group_msg' => '1');
					$result= $this->Mymodel->add('chat', $data);
					
					
					if(!empty($result)){
						$chat_id = $result;
						$response['chat_id'] = $chat_id;
						$response['status'] = 1;
						$receiverId = implode(',', @$receiver_id);
						$chat_query = $this->db->query("select * from chat where sender_id = ".@$sender_id." and receiver_id = '".@$receiverId."' and event_id = ".@$event_id." and id = ".@$chat_id."")->row();
						
						$user_image = $this->Mymodel->get_single_row_info('image', 'users', 'id='.$chat_query->sender_id.'', '', 1);
						//echo $this->db->last_query();
						
						$response['sender_image'] = !empty($user_image->image) ? base_url('uploads/profile/'.@$user_image->image.'') : base_url('uploads/unnamed.jpg');
						$response['sender_message'] = $chat_query->message;
						$response['sender_date'] = date('M d Y', strtotime($chat_query->created_at));
						$response['sender_time'] = date('h:i A', strtotime($chat_query->created_at));
						$response['sender_file'] = '';
						
					}else{
						$response['status'] = 0;
						//$response['message'] = 'Some error ocure.Please try again.';
					}
				}
				

			}else{
				$response = array(
					'vali_error'   => 1,
					'sender_id_err' => form_error('sender_id'),
					'receiver_id_err' => form_error('receiver_id'),
					'event_id_err' => form_error('event_id'),
					'message_err' => form_error('message'),
				);
			}
		}
		echo json_encode($response);
	}
	function get_invited_user_info(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$id = $this->input->post('id');
			$row = $this->db->query("select * from event_invited_people where id = ".@$id."")->row();
			$response['email'] = $row->email;
			$response['distributed_event_price'] = $row->distributed_event_price;
		}
		echo json_encode($response);
	}
	
	function update_invitee(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			
			
			$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
			$this->form_validation->set_rules('amount', 'Amount', 'required|trim|numeric');
			if($this->form_validation->run() == true){
				$checkemailexist = $this->db->query("select * from event_invited_people where id =".trim(strip_tags($this->input->post('id')))."")->row();
				
				if(@$checkemailexist->email != trim(strip_tags(@$this->input->post('email')))){
					$email_exit = $this->db->query("select * from event_invited_people where email ='".$this->input->post('email')."' and event_id = ".$this->input->post('event_id')."")->num_rows();
					
					if($email_exit > 0){
						$response['email_exist'] = 'This email address is already invited for this event';
						echo json_encode($response);exit();
					}else{
						
						$clientamount = $this->input->post('amount');
						$total_amount_sum = $this->Mymodel->total_sum(trim(strip_tags(@$this->input->post('event_id'))));
						$total_event_amount = $clientamount + $total_amount_sum->totalAmount;
						$eventPrice = $this->Mymodel->get_single_row_info('event_price', 'event', 'event_id='.trim(strip_tags(@$this->input->post('event_id'))).'', '', 1);
						if(@$total_event_amount <= @$eventPrice->event_price){
							$data = array('email' => $this->input->post('email'), 'distributed_event_price' => $this->input->post('amount'));
							$result = $this->Mymodel->update($data, 'event_invited_people', array('event_id' => $this->input->post('event_id'), 'id' => $this->input->post('id')));
							if(!empty($result)){
								 // $event_info = $this->Mymodel->get_single_row_info('event_name, user_id', 'event', 'event_id='.trim(strip_tags(@$this->input->post('event_id'))).'', '', 1);
									
								 // $user_info = $this->Mymodel->get_single_row_info('fname, lname', 'users', 'id='.$event_info->user_id.'', '', 1);
								 // $from = $user_info->fname.' '.@$user_info->lname;
								 // $this->sendMail(@$this->input->post('email'), $event_info->event_name, $from, $this->input->post('amount'));
								
								$response['status'] = 1;
								$response['message'] = 'Invited people updated successfully.';
							}
						}else{
							$response['large_amount'] = 'Your have enter distributed amount greater than event amount.Please enter small amount.';
						}

					}
					
					
				}else{
					$clientamount = $this->input->post('amount');
					$total_amount_sum = $this->Mymodel->total_sum(trim(strip_tags(@$this->input->post('event_id'))));
					$total_event_amount = $clientamount + $total_amount_sum->totalAmount;
					$eventPrice = $this->Mymodel->get_single_row_info('event_price', 'event', 'event_id='.trim(strip_tags(@$this->input->post('event_id'))).'', '', 1);
					if(@$total_event_amount <= @$eventPrice->event_price){
						$data = array('email' => $this->input->post('email'), 'distributed_event_price' => $this->input->post('amount'));
						$result = $this->Mymodel->update($data, 'event_invited_people', array('event_id' => $this->input->post('event_id'), 'id' => $this->input->post('id')));
						if(!empty($result)){
							
							 // $event_info = $this->Mymodel->get_single_row_info('event_name, user_id', 'event', 'event_id='.trim(strip_tags(@$this->input->post('event_id'))).'', '', 1);
								
							 // $user_info = $this->Mymodel->get_single_row_info('fname, lname', 'users', 'id='.$event_info->user_id.'', '', 1);
							 // $from = $user_info->fname.' '.@$user_info->lname;
							 // $this->sendMail(@$this->input->post('email'), $event_info->event_name, $from, $this->input->post('amount'));
								
							$response['status'] = 1;
							$response['message'] = 'Invited people updated successfully.';
						}
					}else{
						$response['large_amount'] = 'Your have enter distributed amount greater than event amount.Please enter small amount.';
					}
					
				}
				
			}else{
				$response = array(
					'vali_error'   => 1,
					'email_err' => form_error('email'),
					'amount_err' => form_error('amount'),
				);
			}
		}
		echo json_encode($response);
	}
	
	function send_email_updated_invited(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			if(!empty(@$this->input->post('event_id'))){
				$event_info = $this->Mymodel->get_single_row_info('event_name, user_id, event_date, event_time', 'event', 'event_id='.trim(strip_tags(@$this->input->post('event_id'))).'', '', 1);
				$user_info = $this->Mymodel->get_single_row_info('fname, lname', 'users', 'id='.$event_info->user_id.'', '', 1);
				$from = $user_info->fname.' '.@$user_info->lname;
				$date = $event_info->event_date.' '.$event_info->event_time;
				$send = $this->sendMail(@$this->input->post('email'), $event_info->event_name, $from, $this->input->post('amount'), $date);
				if(!empty($send)){
					echo 'send mail successfully.';
				}else{
					echo 'not sent.';
				}
			}
		}
	}
	function updated_event_notify(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			if(!empty(@$this->input->post('event_id'))){
				$get_invited_people = $this->db->query("select * from event_invited_people where event_id = ".@$this->input->post('event_id')."")->result();
				if(!empty(@$get_invited_people)){
					$event_info = $this->Mymodel->get_single_row_info('event_name, user_id', 'event', 'event_id='.trim(strip_tags(@$this->input->post('event_id'))).'', '', 1);
					
		
						$from_email = "info@madetosplit.com"; 
						$imagePath = base_url() . 'uploads/logos/logo.png';
						$imagebackPath = '';
						$mesg = "<!Doctype html>
						<html>
							<head>
								<meta charset='utf-8'>
								<meta name='viewport' content='width=device-width, initial-scale=1'>
								<title>Invite People</title>
								<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
								</head>
							<body>
								<div style='max-width:600px;
								margin:auto;
								border:1px solid #eee;
								box-shadow:0 0 10px rgba(0, 0, 0, .15);
								line-height:17px;
								font-size:13px;
								box-sizing:border-box; -webkit-print-color-adjust: exact;font-family: Poppins, sans-serif; background:url(".$imagebackPath.")'>
									<div style='padding:20px; box-sizing: border-box;text-align: center; background: #fff;'>
										<a href='#'><img src='".$imagePath."' style='width: 350px; height80px;'></a>
									</div>
									<div style='width: 400px; margin:50px auto;background: #ffffffd1;padding: 50px;text-align: center;'>
										<h1 style=' font-size: 30px; line-height: 32px; color: #0b0b0b; margin: 30px 0;'>Dear User</h1>
										<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;'>There is update in event (".@$event_info->event_name."). Please check updated event. </p>

										<a href='".base_url('event/details?eId='.base64_encode(@$this->input->post('event_id')).'')."' >Check Here</a>
									</div>
									
									<div style='background: #000;
									text-align: left;
									box-sizing: border-box;
									width: 100%;
									padding: 20px 50px;
									color: #fff;'>
										<p style='margin: 5px 0;font-size: 12px;'>Warm Regards,</p>
										<p style='margin: 5px 0;font-size: 12px;'>Made to Split</p>
										<p style='margin: 5px 0;font-size: 12px;'><strong>Email:</strong> <a href='#' style='color: #78daff;'>info@madetosplit.com</a></p>
										<br/>
										<p style='margin: 5px 0;font-size: 11px;'>This is an automated response, please do not reply.</p>
									</div>
								</div>
							</body>
						</html>";
						$subject = "Updated event notify (".@$event_info->event_name.")";
						foreach(@$get_invited_people as $k => $v){
							$this->Mymodel->send_mail($v->email, $from_email, $mesg, $subject, 'rameshwebdev21@gmail.com', 'gqbtiijrzaljwkhz');
						}
				}
			}
		}
	}
	function send_email_cohost(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$event_id = $this->input->post('event_id');
			$co_host_id = $this->input->post('co_host_id');
			
			$event_info = $this->Mymodel->get_single_row_info('event_id, event_name, user_id, event_address, event_date, event_time', 'event', 'event_id='.@$event_id.'', '', 1);
			$co_host_info = $this->Mymodel->get_single_row_info('id, fname, lname, email', 'users', 'id='.@$co_host_id.'', '', 1);
			$host_info = $this->Mymodel->get_single_row_info('id, fname, lname, email', 'users', 'id='.@$event_info->user_id.'', '', 1);
			$from_email = "info@madetosplit.com"; 
			$subject = "Selected as Co-Host (".@$event_info->event_name.")";
			$imagePath = base_url() . 'uploads/logos/logo.png';
			$imagebackPath = '';
			
			$mesg = "<!Doctype html>
				<html>
				<head>
					<meta charset='utf-8'>
					<meta name='viewport' content='width=device-width, initial-scale=1'>
					<title>Invite People</title>
					<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
					</head>
				<body>
					<div style='max-width:600px;
					margin:auto;
					border:1px solid #eee;
					box-shadow:0 0 10px rgba(0, 0, 0, .15);
					line-height:17px;
					font-size:13px;
					box-sizing:border-box; -webkit-print-color-adjust: exact;font-family: Poppins, sans-serif; background:url(".$imagebackPath.")'>
						<div style='padding:20px; box-sizing: border-box;text-align: center; background: #fff;'>
							<a href='#'><img src='".$imagePath."' style='width: 350px; height80px;'></a>
						</div>
						
						<div style='width: 400px; margin:50px auto;background: #ffffffd1;padding: 50px;text-align: center;'>
							<h1 style=' font-size: 30px; line-height: 32px; color: #0b0b0b; margin: 30px 0;'>Dear User</h1>
							<p style='font-size: 15px;color: #262626;line-height: 24px;margin: 20px 0;text-align: justify;'>You are selected as a Co-Host for <strong>(".@$event_info->event_name.")</strong> this event.</p>
						</div>
						
						
						
						<div style='margin: 0px 96px;margin-top: -60px;'>
							<span><strong>Event &nbsp; : &nbsp; </strong>  ".@$event_info->event_name."</span>	<br>
							<span><strong>Venue &nbsp; : &nbsp; </strong>".@$event_info->event_address."</span>	<br>
							<span><strong>Date & Time &nbsp; : &nbsp; </strong>".date('d M, Y', strtotime(@$event_info->event_date)) .' '.@$event_info->event_time."</span>
						</div><br>
						
						<div style='background: #f7931e;width: 20%;margin: 5px 13rem;border-radius: 7px;'>
						<a href='".base_url('event/details?eId='.base64_encode(@$event_info->event_id).'')."' style='padding: 9px 0px;position: absolute;margin: 0px 22px;text-decoration: none;font-size: 14px;font-weight: 900;color: white;'>Check Here</a><br><br>
						</div>
						
						<div style='background: #000;
						text-align: left;
						box-sizing: border-box;
						width: 100%;
						padding: 20px 50px;
						color: #fff;'>
							<p style='margin: 5px 0;font-size: 12px;'>Warm Regards,</p>
							<p style='margin: 5px 0;font-size: 12px;'>Made to Split</p>
							<p style='margin: 5px 0;font-size: 12px;'><strong>Email:</strong> <a href='#' style='color: #78daff;'>info@madetosplit.com</a></p>
							<br/>
							<p style='margin: 5px 0;font-size: 11px;'>This is an automated response, please do not reply.</p>
						</div>
					</div>
				</body>
			</html>";
			
			$this->Mymodel->send_mail($co_host_info->email, $from_email, $mesg, $subject, 'rameshwebdev21@gmail.com', 'gqbtiijrzaljwkhz');
		}
	}
	
}
