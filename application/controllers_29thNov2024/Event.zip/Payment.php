<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
class Payment extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mymodel');
		$this->Mymodel->loggedIn();
	} 
	public function index()
	{
		if(empty(@$_GET['subId'])){
			return false;
		}
		
		if(empty(@$_GET['uId'])){
			return false;
		}
		
		if(empty(@$_GET['amo'])){
			return false;
		}
		
		
		
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			require APPPATH . '/libraries/stripe-php/init.php';
			$this->form_validation->set_rules('stripeToken', 'stripeToken', 'trim|required');
			$this->form_validation->set_rules('card_name', 'Name of Card Holder', 'trim|required');
			$this->form_validation->set_rules('card_amount', 'Amount', 'trim|required');
			$this->form_validation->set_rules('card_sub_id', 'Card Subscription Id', 'trim|required');
			$this->form_validation->set_rules('card_number', 'Card Number', 'trim|required');
			$this->form_validation->set_rules('card_expiry_month', 'Month', 'trim|required');
			$this->form_validation->set_rules('card_expiry_year', 'Year', 'trim|required');
			$this->form_validation->set_rules('card_cvc', 'CVC', 'trim|required');
            if($this->form_validation->run() == true){ 
			
				$stripeToken = $this->input->post('stripeToken');
				$cardholder = strip_tags($this->input->post('card_name'));
				$amount = strip_tags($this->input->post('card_amount_1'));
				$sub_id = strip_tags($this->input->post('card_sub_id'));
				$card_number = strip_tags($this->input->post('card_number'));
				$expiry_month = strip_tags($this->input->post('card_expiry_month'));
				$expiry_year = strip_tags($this->input->post('card_expiry_year'));
				$cvc = strip_tags($this->input->post('card_cvc'));
				$user_id = strip_tags($this->input->post('card_user_id'));
				$email = strip_tags($this->input->post('card_email'));
				$country = strip_tags($this->input->post('card_country'));
				$state = strip_tags($this->input->post('card_state'));
				$city = strip_tags($this->input->post('card_city'));
				$zipcode = strip_tags($this->input->post('card_zipcode'));
				$address = strip_tags($this->input->post('card_address'));
				
				$stripe = array(
				"secret_key"      => "sk_test_51MPhgSIuZrwn6gWgucZ3pq3OGKnLaQMxviXsKtZb4F7tenDBs25KovJkAB4tii3db6CMW1tdWSk2CB9thQ8yOYdX00iUs05KRN",
				"publishable_key" => "pk_test_51MPhgSIuZrwn6gWggTu5pxq41l6ZODzSg2zZ1kjKynv3yR61OZDey3AcNm2iwioDVJqSuJ3TCXJCdOAJn1VaNfyk00QkWY7DPT"
				); 
				\Stripe\Stripe::setApiKey($stripe['secret_key']);
				
				$customer = \Stripe\Customer::create(array(
					'email' => @$email,
					'source'  => $stripeToken
				));
                $sub = $this->Mymodel->get_single_row_info('name, duration', 'subscription', 'id = '.$sub_id.' and status = "1"', '', 1);
				$itemName = @$sub->name;
				$itemNumber = "Test_ITEM".$this->generate_otp(6);
				$itemPrice = $amount * 100;
				$currency = "USD";
				$orderID = "TEST_".$this->generate_otp(6);
				$payDetails = \Stripe\Charge::create(array(
						'amount'   => $itemPrice,
						'currency' => $currency,
						'customer' => $customer->id,
						'description' => $itemName,
						'metadata' => array(
						'order_id' => $orderID
					)
				)); 
				$paymenyResponse = $payDetails->jsonSerialize();
				if($paymenyResponse['amount_refunded'] == 0 && empty($paymenyResponse['failure_code']) && $paymenyResponse['paid'] == 1 && $paymenyResponse['captured'] == 1){
					$amountPaid = $paymenyResponse['amount'];
					$balanceTransaction = $paymenyResponse['balance_transaction'];
					$paidCurrency = $paymenyResponse['currency'];
					$paymentStatus = $paymenyResponse['status'];
					$paymentDate = date("Y-m-d H:i:s");
					if($paymentStatus == 'succeeded'){
						$end_date = $this->end_date(@$sub->duration);
						$tran_data = array(
					    	'user_name' => $cardholder, 'user_id' => $user_id, 'sub_id' => $sub_id, 'order_id' => $orderID, 'tran_id' => $balanceTransaction, 'card_number' => $card_number, 'card_exp_month' => $expiry_month, 'card_exp_year' => $expiry_year, 'address' => $address, 'country' => $country, 'state' => $state, 'city' => $city, 'zipcode' => $zipcode, 'amount' => $amount, 'payment_type' => '1', 'start_date' => date('Y-m-d H:i:s'), 'end_date' => $end_date, 'status' => $paymentStatus, 'currency' => $paidCurrency, 'created_at' => date('Y-m-d H:i:s')
						);
						$result = $this->Mymodel->add('transaction', $tran_data);
						if(!empty($result)){
							$update_query = $this->db->query("update users set sub_id = '".@$sub_id."' where id = ".@$user_id."");
							$msg = '<p>Your subscription payment has been successfully completed. Now you can create an event.<br>Transaction Id : '.@$balanceTransaction.'</p>';
							$this->session->set_flashdata('msg', $msg);
							redirect(base_url('event/add'));
						}
						
					}
				} 				
			}
		}
		
		
	    
		
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Subscription Payment',
			'subpage' => 'payment',
		);
		
		$data['user'] = $this->Mymodel->get_single_row_info('fname, lname, email, address', 'users', 'id = '.base64_decode(@$_GET['uId']).' and status = "1"', '', 1);
		$this->load->view('header', $data);
		$this->load->view('account/sub_payment');
		$this->load->view('footer');
	}
	function end_date($duration = ''){
		
		if($duration == '1-Month'){
			$days = '30 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '2-Month'){
			$days = '60 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '3-Month'){
			$days = '90 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '4-Month'){
			$days = '120 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '5-Month'){
			$days = '150 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '6-Month'){
			$days = '180 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '7-Month'){
			$days = '210 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '8-Month'){
			$days = '240 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '9-Month'){
			$days = '270 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '10-Month'){
			$days = '300 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '11-Month'){
			$days = '330 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '12-Month'){
			$days = '360 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '1-Year'){
			$days = '360 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}elseif($duration == '2-Year'){
			$days = '720 Days';
			$endDate = date('Y-m-d',strtotime(''.$days.'',strtotime(date('Y-m-d')))) . PHP_EOL;
		}
		return $endDate;	
	}
	public function generate_otp($length)
	{
		$characters = '123456789';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++)
		{
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	function event(){
		if(empty(@$_GET['eId'])){
			return false;
		}
		
		if(empty(@$_GET['amo'])){
			return false;
		}
		
		
		$event_id = base64_decode(@$_GET['eId']);
		$amount = base64_decode(@$_GET['amo']);
		$userId = $this->session->userdata('loguserId');
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Event Payment',
			'subpage' => 'payment',
		);
		
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			require APPPATH . '/libraries/stripe-php/init.php';
			$this->form_validation->set_rules('stripeToken', 'stripeToken', 'trim|required');
			$this->form_validation->set_rules('card_name', 'Name of Card Holder', 'trim|required');
			$this->form_validation->set_rules('card_amount', 'Amount', 'trim|required');
			$this->form_validation->set_rules('card_number', 'Card Number', 'trim|required');
			$this->form_validation->set_rules('card_expiry_month', 'Month', 'trim|required');
			$this->form_validation->set_rules('card_expiry_year', 'Year', 'trim|required');
			$this->form_validation->set_rules('card_cvc', 'CVC', 'trim|required');
            if($this->form_validation->run() == true){
				$stripeToken = $this->input->post('stripeToken');
				$cardholder = strip_tags($this->input->post('card_name'));
				$amount = strip_tags($this->input->post('card_amount_1'));
				$card_number = strip_tags($this->input->post('card_number'));
				$expiry_month = strip_tags($this->input->post('card_expiry_month'));
				$expiry_year = strip_tags($this->input->post('card_expiry_year'));
				$cvc = strip_tags($this->input->post('card_cvc'));
				$user_id = strip_tags($this->input->post('card_user_id'));
				$email = strip_tags($this->input->post('card_email'));
				$country = strip_tags($this->input->post('card_country'));
				$state = strip_tags($this->input->post('card_state'));
				$city = strip_tags($this->input->post('card_city'));
				$zipcode = strip_tags($this->input->post('card_zipcode'));
				$address = strip_tags($this->input->post('card_address'));
				$payment_in = strip_tags($this->input->post('payment_in'));
				
				$stripe = array(
					"secret_key"      => "sk_test_51MPhgSIuZrwn6gWgucZ3pq3OGKnLaQMxviXsKtZb4F7tenDBs25KovJkAB4tii3db6CMW1tdWSk2CB9thQ8yOYdX00iUs05KRN",
					"publishable_key" => "pk_test_51MPhgSIuZrwn6gWggTu5pxq41l6ZODzSg2zZ1kjKynv3yR61OZDey3AcNm2iwioDVJqSuJ3TCXJCdOAJn1VaNfyk00QkWY7DPT"
				); 
				\Stripe\Stripe::setApiKey($stripe['secret_key']);
				
				$customer = \Stripe\Customer::create(array(
					'email' => @$email,
					'source'  => $stripeToken
				));
                $event = $this->Mymodel->get_single_row_info('event_name', 'event', 'event_id = '.$event_id.' and status = "1"', '', 1);
				
				$itemName = @$event->name;
				$itemNumber = "Test_ITEM".$this->generate_otp(6);
				$itemPrice = $amount * 100;
				$currency = "USD";
				$orderID = "TEST_".$this->generate_otp(6);
				$payDetails = \Stripe\Charge::create(array(
						'amount'   => $itemPrice,
						'currency' => $currency,
						'customer' => $customer->id,
						'description' => $itemName,
						'metadata' => array(
						'order_id' => $orderID
					)
				)); 
				$paymenyResponse = $payDetails->jsonSerialize();
				
				if($paymenyResponse['amount_refunded'] == 0 && empty($paymenyResponse['failure_code']) && $paymenyResponse['paid'] == 1 && $paymenyResponse['captured'] == 1){
					$amountPaid = $paymenyResponse['amount'];
					$balanceTransaction = $paymenyResponse['balance_transaction'];
					$paidCurrency = $paymenyResponse['currency'];
					$paymentStatus = $paymenyResponse['status'];
					$paymentDate = date("Y-m-d H:i:s");
					if($paymentStatus == 'succeeded'){
						$tran_data = array(
					    	'user_name' => $cardholder, 'user_id' => $user_id, 'order_id' => $orderID, 'tran_id' => $balanceTransaction, 'card_number' => $card_number, 'card_exp_month' => $expiry_month, 'card_exp_year' => $expiry_year, 'address' => $address, 'country' => $country, 'state' => $state, 'city' => $city, 'zipcode' => $zipcode, 'amount' => $amount, 'payment_type' => '2', 'status' => $paymentStatus, 'currency' => $paidCurrency, 'event_id' => $event_id, 'payment_in' => $payment_in, 'created_at' => date('Y-m-d H:i:s')
						);
						$result = $this->Mymodel->add('transaction', $tran_data);
						if(!empty($result)){
							$update_query = $this->db->query("update event_invited_people set transaction = 'Paid' where email = '".@$email."' and event_id = ".@$event_id."");
							$msg = '<p>Your event payment has been successfully completed. Now you can create an event.<br>Transaction Id : '.@$balanceTransaction.'</p>';
							$this->session->set_flashdata('msg', $msg);
							redirect(base_url('event/details?eId='.@$_GET['eId'].''));
						}
						
					}
				} 
			}
		}
		$data['user'] = $this->Mymodel->get_single_row_info('fname, lname, email, address', 'users', 'id = '.@$userId.' and status = "1"', '', 1);
		$this->load->view('header', $data);
		$this->load->view('account/event_payment');
		$this->load->view('footer');
	}
	
}