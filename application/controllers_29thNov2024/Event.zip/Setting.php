<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller {

	
	 public function __construct()
	{
		parent::__construct();
		$this->load->model('Mymodel');
		$this->Mymodel->loggedIn();
	}
	
	 public function index(){
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Setting',
			'subpage' => 'setting',
		);


		$userId = $this->session->userdata('loguserId');
		$query = $this->db->query("select * from users where status = '1' and id = ".@$userId." ORDER BY id DESC");
		$data['user'] = ($query->num_rows() > 0) ? $query->row() : FALSE;
		$this->load->view('header', $data);
		$this->load->view('account/setting');
		$this->load->view('footer');
	}
	
	function changepassword(){
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Change Password',
			'subpage' => 'changepassword',
		);
		
		$userId = $this->session->userdata('loguserId');
		$query = $this->db->query("select * from users where status = '1' and id = ".@$userId." ORDER BY id DESC");
		$data['user'] = ($query->num_rows() > 0) ? $query->row() : FALSE;
		$this->load->view('header', $data);
		$this->load->view('account/changepassword');
		$this->load->view('footer');
	}
	
	function customize_pay(){
		$data = array(
			'title' => 'Made to Split',
			'page' => 'Customize Payment',
			'subpage' => 'customizepay',
		);
		
		$userId = $this->session->userdata('loguserId');
		
		$query = $this->db->query("select * from users where status = '1' and id = ".@$userId." ORDER BY id DESC");
		$data['user'] = ($query->num_rows() > 0) ? $query->row() : FALSE;
		
		$data['customize_payment'] = $this->Mymodel->get_single_row_info('customize_payment', 'users', 'id='.$userId.'', '', 1);
		$this->load->view('header', $data);
		$this->load->view('account/customize_payment');
		$this->load->view('footer');
	}
	
	function change_paystatus(){
		
		if ($this->input->post('userId')) {
			$userId = $this->input->post('userId');
			$status = $this->input->post('status');
			if ($status == 1) {
				$msg = 'Your customize payment status is active.';
			} else {
				$msg = 'Your customize payment status is inactive';
			}
			
			if ($this->Adminmodel->update(['customize_payment'=>$status], 'users', ['id'=>$userId])) {
				$response['status'] = 1;
				$response['message'] = $msg;
				
			} else {
				$response['status'] = 0;
				$response['message'] = 'Some error occured, Please try again!.';
			}
		}
	    echo json_encode($response);
	}
	
	function delete_account($id){
		if(empty($id)){
			return false;
		}
		$userinfo = $this->Mymodel->get_single_row_info('email, image', 'users', 'id='.@$id.'', '', 1);
		$delete_user_query = $this->db->query("delete from users where id = ".$id."");
		$delete_userevent_query = $this->db->query("delete from event where user_id = ".$id."");
		$delete_user_eventgallery_query = $this->db->query("delete from event_gallery where user_id = ".$id."");
		$delete_invitedpeople_query = $this->db->query("delete from event_invited_people where user_id = ".$id."");
		$delete_chat_query = $this->db->query("delete from chat where sender_id = ".$id."");
		$imagePath = base_url('uploads/profile/'.@$userinfo->image.'');
		unlink($imagePath);
		redirect(base_url('login/logout'));
		
	}
}	
	